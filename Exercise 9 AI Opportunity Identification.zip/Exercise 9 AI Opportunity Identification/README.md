# AI Value Radar

Enterprise AI Opportunity Discovery & Investment Prioritization Platform.

## Run using CMD

python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python -m streamlit run app.py

## Mandatory Deliverables
- Opportunity backlog
- Prioritization matrix
