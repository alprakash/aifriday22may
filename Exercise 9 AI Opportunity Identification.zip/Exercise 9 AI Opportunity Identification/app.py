
import os
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
import httpx
from openai import OpenAI

# =========================================================
# APP CONFIG
# =========================================================
st.set_page_config(
    page_title="TransformIQ AI",
    page_icon="🚀",
    layout="wide"
)

load_dotenv()

KEY = os.getenv("KEY")
ENDPOINT = os.getenv("ENDPOINT")
MODEL = os.getenv("MODEL", "azure/genailab-maas-gpt-4o-mini")

client = OpenAI(
    api_key=KEY,
    base_url=ENDPOINT,
    http_client=httpx.Client(verify=False)
)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
BACKLOG_FILE = DATA_DIR / "opportunity_backlog.csv"

# =========================================================
# MASTER DATA
# =========================================================
BUSINESS_AREAS = [
    "IT Operations",
    "Delivery",
    "PMO",
    "Architecture",
    "Support",
    "Business Operations",
    "Governance",
    "Finance",
    "HR / Workforce"
]

COMPLEXITY_LEVELS = ["Low", "Medium", "High"]
STATUS_LIST = ["New", "Validated", "Pilot", "Approved", "Deferred"]

DEFAULT_BACKLOG = pd.DataFrame([
    {
        "id": "AI001",
        "use_case": "AI-Assisted Incident Trend Analysis",
        "business_area": "IT Operations",
        "problem": "Support teams manually review repeated incidents and miss recurring failure patterns.",
        "benefits": "Reduce recurring incidents, faster RCA, better problem management.",
        "users": "L2 Support, SRE, Incident Managers",
        "inputs": "Incident tickets, alerts, RCA reports, monitoring logs",
        "business_value": 5,
        "feasibility": 4,
        "strategic_relevance": 5,
        "measurable_impact": 5,
        "complexity": "Medium",
        "risks": "Data quality and integration with monitoring tools",
        "status": "Validated"
    },
    {
        "id": "AI002",
        "use_case": "Automated Project Status Summarization",
        "business_area": "PMO",
        "problem": "Project managers spend significant time preparing weekly status reports.",
        "benefits": "Faster reporting, consistent status, reduced manual effort.",
        "users": "PMO, Project Managers, Delivery Leaders",
        "inputs": "Jira updates, project plans, RAID logs, timesheets",
        "business_value": 4,
        "feasibility": 5,
        "strategic_relevance": 4,
        "measurable_impact": 4,
        "complexity": "Low",
        "risks": "Incomplete project updates may reduce summary accuracy",
        "status": "Validated"
    },
    {
        "id": "AI003",
        "use_case": "Intelligent Capacity Forecasting",
        "business_area": "Delivery",
        "problem": "Resource planning is reactive and effort forecasting is inconsistent.",
        "benefits": "Better staffing, reduced delivery risk, improved utilization.",
        "users": "Delivery Managers, Resource Managers",
        "inputs": "Timesheets, sprint velocity, demand pipeline, leave plans",
        "business_value": 5,
        "feasibility": 3,
        "strategic_relevance": 5,
        "measurable_impact": 4,
        "complexity": "High",
        "risks": "Forecast depends on historical data quality and demand accuracy",
        "status": "New"
    },
    {
        "id": "AI004",
        "use_case": "Architecture Pattern Recommendation",
        "business_area": "Architecture",
        "problem": "Teams repeatedly design solutions without reusing approved architecture patterns.",
        "benefits": "Faster solution design, better governance, reduced rework.",
        "users": "Architects, Tech Leads, Engineering Teams",
        "inputs": "Architecture repository, solution designs, technology standards",
        "business_value": 4,
        "feasibility": 3,
        "strategic_relevance": 5,
        "measurable_impact": 3,
        "complexity": "High",
        "risks": "Requires well-maintained architecture knowledge base",
        "status": "New"
    },
    {
        "id": "AI005",
        "use_case": "Knowledge Search for Support Teams",
        "business_area": "Support",
        "problem": "Support teams struggle to find the right SOP, RCA, or knowledge article quickly.",
        "benefits": "Reduced resolution time, improved first-time-right support.",
        "users": "L1/L2 Support, Service Desk, Operations",
        "inputs": "Knowledge articles, SOPs, historical tickets, runbooks",
        "business_value": 5,
        "feasibility": 4,
        "strategic_relevance": 4,
        "measurable_impact": 5,
        "complexity": "Medium",
        "risks": "Knowledge base freshness and access control",
        "status": "Validated"
    },
    {
        "id": "AI006",
        "use_case": "Governance Action Tracking Assistant",
        "business_area": "Governance",
        "problem": "Governance actions from reviews are tracked manually and often delayed.",
        "benefits": "Improved compliance, better action closure, leadership visibility.",
        "users": "Governance Teams, PMO, Delivery Leaders",
        "inputs": "Review minutes, action logs, risk registers, audit findings",
        "business_value": 3,
        "feasibility": 4,
        "strategic_relevance": 4,
        "measurable_impact": 3,
        "complexity": "Medium",
        "risks": "Dependency on accurate action owner mapping",
        "status": "New"
    }
])

# =========================================================
# CSS
# =========================================================
st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #f8fafc 0%, #eff6ff 45%, #f5f3ff 100%);
}
[data-testid="stSidebar"] {
    background: #111827;
}
[data-testid="stSidebar"] * {
    color: #ffffff !important;
}
h1,h2,h3,h4,h5,h6,p,span,label,div {
    color: #111827 !important;
}
.hero {
    background: linear-gradient(135deg, #111827, #4338ca);
    padding: 30px;
    border-radius: 24px;
    margin-bottom: 22px;
    box-shadow: 0 18px 45px rgba(17,24,39,0.20);
}
.hero h1 {
    color: white !important;
    font-size: 44px;
    font-weight: 900;
    margin: 0;
}
.hero p {
    color: #e0e7ff !important;
    font-size: 17px;
    margin-top: 8px;
}
.badge {
    display: inline-block;
    background: #ecfeff;
    color: #155e75 !important;
    padding: 8px 14px;
    border-radius: 999px;
    border: 1px solid #06b6d4;
    font-weight: 800;
    margin-top: 12px;
}
.card {
    background: white;
    border: 1px solid #cbd5e1;
    border-radius: 18px;
    padding: 18px;
    margin-bottom: 16px;
    box-shadow: 0 12px 30px rgba(15,23,42,0.08);
}
.idea-card {
    background: linear-gradient(135deg, #ffffff, #eef2ff);
    border: 1px solid #a5b4fc;
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 10px;
}
.idea-card b {
    color: #3730a3 !important;
}
</style>
""", unsafe_allow_html=True)

# =========================================================
# DATA HELPERS
# =========================================================
def ensure_file():
    if not BACKLOG_FILE.exists():
        DEFAULT_BACKLOG.to_csv(BACKLOG_FILE, index=False)

def load_backlog():
    ensure_file()
    df = pd.read_csv(BACKLOG_FILE)
    required = [
        "id", "use_case", "business_area", "problem", "benefits", "users",
        "inputs", "business_value", "feasibility", "strategic_relevance",
        "measurable_impact", "complexity", "risks", "status"
    ]
    for col in required:
        if col not in df.columns:
            df[col] = ""
    for col in ["business_value", "feasibility", "strategic_relevance", "measurable_impact"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)
    return df[required]

def save_backlog(df):
    df.to_csv(BACKLOG_FILE, index=False)

def next_id(df):
    nums = []
    for i in df["id"]:
        try:
            nums.append(int(str(i).replace("AI", "")))
        except Exception:
            pass
    return f"AI{max(nums)+1:03d}" if nums else "AI001"

def calculate_scores(df):
    df = df.copy()
    df["total_score"] = (
        df["business_value"] * 0.35 +
        df["feasibility"] * 0.25 +
        df["strategic_relevance"] * 0.25 +
        df["measurable_impact"] * 0.15
    ).round(2)

    def decision(row):
        if row["total_score"] >= 4.3 and row["feasibility"] >= 3:
            return "Pursue First"
        if row["total_score"] >= 3.5:
            return "Validate Further"
        return "Defer"

    df["priority_decision"] = df.apply(decision, axis=1)
    return df.sort_values("total_score", ascending=False)

# =========================================================
# AI AGENT
# =========================================================
def ai_agent(task, data_text):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": "You are an enterprise AI transformation consultant. You help leadership prioritize AI opportunities using business value, feasibility, strategic relevance, measurable impact, risks, dependencies, and roadmap thinking."
            },
            {
                "role": "user",
                "content": f"""
Opportunity Backlog / Data:
{data_text}

Task:
{task}

Return a structured leadership-ready output with:
1. Executive summary
2. Prioritization logic
3. Recommended opportunities to pursue first
4. Opportunities requiring validation
5. Deferred opportunities
6. Key risks/dependencies
7. Transformation roadmap
"""
            }
        ],
        temperature=0.25,
        max_tokens=2000
    )
    return response.choices[0].message.content

backlog_df = load_backlog()
scored_df = calculate_scores(backlog_df)

# =========================================================
# SIDEBAR
# =========================================================
st.sidebar.title("🚀 TransformIQ AI")
page = st.sidebar.radio(
    "Menu",
    [
        "Executive Dashboard",
        "Opportunity Backlog",
        "Prioritization Matrix",
        "AI Strategy Agent",
        "Roadmap",
        "Data Explorer"
    ]
)

# =========================================================
# HEADER
# =========================================================
st.markdown("""
<div class="hero">
<h1>TransformIQ AI</h1>
<p>AI Opportunity Discovery, Prioritization & Transformation Roadmap Platform</p>
<span class="badge">Leadership View • Opportunity Backlog • Prioritization Matrix</span>
</div>
""", unsafe_allow_html=True)

# =========================================================
# PAGES
# =========================================================
if page == "Executive Dashboard":
    pursue = len(scored_df[scored_df["priority_decision"] == "Pursue First"])
    validate = len(scored_df[scored_df["priority_decision"] == "Validate Further"])
    defer = len(scored_df[scored_df["priority_decision"] == "Defer"])

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total AI Opportunities", len(scored_df))
    c2.metric("Pursue First", pursue)
    c3.metric("Validate Further", validate)
    c4.metric("Deferred", defer)

    st.markdown("""
<div class="card">
<b>Purpose:</b> This platform helps leadership identify, evaluate and prioritize AI use cases across delivery, IT operations, architecture, PMO, support and business functions.
</div>
""", unsafe_allow_html=True)

    st.subheader("Top Prioritized Opportunities")
    st.dataframe(scored_df[["id", "use_case", "business_area", "total_score", "priority_decision", "complexity", "status"]], use_container_width=True)

    st.subheader("Decision Distribution")
    st.bar_chart(scored_df["priority_decision"].value_counts())

elif page == "Opportunity Backlog":
    st.subheader("Create New AI Opportunity")

    with st.form("new_opportunity"):
        use_case = st.text_input("Use Case Name")
        business_area = st.selectbox("Business Area", BUSINESS_AREAS)
        problem = st.text_area("Business Problem")
        benefits = st.text_area("Expected Benefits")
        users = st.text_input("Likely Users", value="Delivery Leaders, Support Teams, PMO")
        inputs = st.text_area("Data / Process Inputs Required")
        c1, c2 = st.columns(2)
        with c1:
            business_value = st.slider("Business Value", 1, 5, 4)
            feasibility = st.slider("Implementation Feasibility", 1, 5, 3)
        with c2:
            strategic_relevance = st.slider("Strategic Relevance", 1, 5, 4)
            measurable_impact = st.slider("Measurable Impact", 1, 5, 4)

        complexity = st.selectbox("Implementation Complexity", COMPLEXITY_LEVELS)
        risks = st.text_area("Key Risks / Dependencies")
        status = st.selectbox("Status", STATUS_LIST)

        submit = st.form_submit_button("Add Opportunity")

        if submit:
            if not use_case.strip():
                st.error("Use case name is required.")
            else:
                new_row = {
                    "id": next_id(backlog_df),
                    "use_case": use_case,
                    "business_area": business_area,
                    "problem": problem,
                    "benefits": benefits,
                    "users": users,
                    "inputs": inputs,
                    "business_value": business_value,
                    "feasibility": feasibility,
                    "strategic_relevance": strategic_relevance,
                    "measurable_impact": measurable_impact,
                    "complexity": complexity,
                    "risks": risks,
                    "status": status
                }
                updated = pd.concat([backlog_df, pd.DataFrame([new_row])], ignore_index=True)
                save_backlog(updated)
                st.success(f"Opportunity {new_row['id']} created.")
                st.rerun()

    st.subheader("Opportunity Backlog")
    st.dataframe(scored_df, use_container_width=True)

    st.subheader("Update Opportunity Status")
    selected_id = st.selectbox("Select Opportunity", scored_df["id"].tolist())
    selected = scored_df[scored_df["id"] == selected_id].iloc[0]

    new_status = st.selectbox(
        "Update Status",
        STATUS_LIST,
        index=STATUS_LIST.index(selected["status"]) if selected["status"] in STATUS_LIST else 0
    )

    if st.button("Update Status", use_container_width=True):
        idx = backlog_df[backlog_df["id"] == selected_id].index[0]
        backlog_df.at[idx, "status"] = new_status
        save_backlog(backlog_df)
        st.success(f"{selected_id} updated.")
        st.rerun()

elif page == "Prioritization Matrix":
    st.subheader("Prioritization Matrix")

    matrix_df = scored_df.copy()
    st.dataframe(
        matrix_df[[
            "id", "use_case", "business_area", "business_value", "feasibility",
            "strategic_relevance", "measurable_impact", "total_score",
            "complexity", "priority_decision"
        ]],
        use_container_width=True
    )

    st.subheader("Business Value vs Feasibility")
    st.scatter_chart(
        matrix_df,
        x="feasibility",
        y="business_value",
        color="total_score",
        size="measurable_impact"
    )

    st.markdown("""
### Decision Rules
- **Pursue First**: High total score and feasible implementation.
- **Validate Further**: Strong potential but needs data/process validation.
- **Defer**: Lower score or high uncertainty.
""")

elif page == "AI Strategy Agent":
    st.markdown("""
<div class="idea-card"><b>AI Strategy Agent</b> reviews the full opportunity backlog and recommends what leadership should pursue first.</div>
<div class="idea-card"><b>Roadmap Agent</b> converts prioritized opportunities into a transformation roadmap.</div>
<div class="idea-card"><b>Risk Agent</b> identifies data, governance, adoption and implementation risks.</div>
""", unsafe_allow_html=True)

    question = st.text_area(
        "Ask AI Strategy Agent",
        value="Prioritize the AI opportunities and recommend which should be pursued first, validated further, and deferred."
    )

    if st.button("Run AI Strategy Agent", use_container_width=True):
        st.subheader("Opportunity Backlog Used")
        st.dataframe(scored_df, use_container_width=True)

        with st.spinner("AI Strategy Agent analyzing opportunities..."):
            result = ai_agent(question, scored_df.to_string(index=False))

        st.subheader("AI Strategy Recommendation")
        st.markdown(result)

elif page == "Roadmap":
    st.subheader("Transformation Roadmap")

    pursue_df = scored_df[scored_df["priority_decision"] == "Pursue First"]
    validate_df = scored_df[scored_df["priority_decision"] == "Validate Further"]
    defer_df = scored_df[scored_df["priority_decision"] == "Defer"]

    c1, c2, c3 = st.columns(3)

    with c1:
        st.markdown("### Phase 1: Pursue First")
        st.dataframe(pursue_df[["id", "use_case", "business_area", "total_score"]], use_container_width=True)

    with c2:
        st.markdown("### Phase 2: Validate Further")
        st.dataframe(validate_df[["id", "use_case", "business_area", "total_score"]], use_container_width=True)

    with c3:
        st.markdown("### Phase 3: Defer")
        st.dataframe(defer_df[["id", "use_case", "business_area", "total_score"]], use_container_width=True)

    if st.button("Generate AI Roadmap Narrative", use_container_width=True):
        roadmap_prompt = "Create a 90-day AI transformation roadmap from this prioritization backlog."
        result = ai_agent(roadmap_prompt, scored_df.to_string(index=False))
        st.markdown(result)

elif page == "Data Explorer":
    st.subheader("Raw Opportunity Backlog CSV")
    st.dataframe(backlog_df, use_container_width=True)

    st.download_button(
        "Download Opportunity Backlog CSV",
        backlog_df.to_csv(index=False),
        file_name="opportunity_backlog.csv",
        mime="text/csv"
    )

    st.subheader("Scored Prioritization Matrix")
    st.download_button(
        "Download Prioritization Matrix CSV",
        scored_df.to_csv(index=False),
        file_name="prioritization_matrix.csv",
        mime="text/csv"
    )

st.caption("TransformIQ AI • AI Opportunity Backlog • Prioritization Matrix • Transformation Roadmap")
