import os
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
import httpx
from openai import OpenAI

st.set_page_config(page_title="SentinelOps ITSM", page_icon="🚨", layout="wide")

load_dotenv()

KEY = os.getenv("KEY")
ENDPOINT = os.getenv("ENDPOINT")
MODEL = os.getenv("MODEL")

client = OpenAI(
    api_key=KEY,
    base_url=ENDPOINT,
    http_client=httpx.Client(verify=False)
)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
INCIDENTS_FILE = DATA_DIR / "incidents.csv"

ASSIGNEES = [
    "Ops Team",
    "DBA Team",
    "SRE Team",
    "Application Team",
    "Monitoring Team",
    "Settlement Team",
    "App Support"
]

DEFAULT_INCIDENTS = pd.DataFrame([
    {
        "id": "INC001",
        "title": "UPI Payment Gateway Outage",
        "status": "Open",
        "priority": "P1",
        "assigned_to": "Ops Team",
        "created": "2026-05-22 09:00",
        "resolved": "",
        "description": "Payment outage during peak hours. DB CPU crossed 88%, queue latency increased, payment timeout started, reconciliation batch failed, and SLA breach risk crossed 90%.",
        "closure_notes": ""
    },
    {
        "id": "INC002",
        "title": "Merchant Settlement Delay",
        "status": "In Progress",
        "priority": "P2",
        "assigned_to": "Settlement Team",
        "created": "2026-05-22 11:15",
        "resolved": "",
        "description": "Merchant settlement processing delayed due to downstream batch dependency timeout.",
        "closure_notes": ""
    }
])

ALERTS = pd.DataFrame([
    {"time": "09:00", "service": "Database", "alert": "CPU crossed 88%", "severity": "Warning"},
    {"time": "09:10", "service": "Database", "alert": "Deadlock detected", "severity": "Critical"},
    {"time": "09:12", "service": "Payment API", "alert": "Transaction timeout started", "severity": "Critical"},
    {"time": "09:20", "service": "Batch Engine", "alert": "Reconciliation batch failed", "severity": "Critical"}
])

PREVENTION = pd.DataFrame([
    {"action": "Add DB lock monitoring", "owner": "DBA Team"},
    {"action": "Implement AI alert correlation", "owner": "Monitoring Team"},
    {"action": "Move reconciliation batch outside peak hours", "owner": "Application Team"}
])

st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #eef2ff 0%, #f8fafc 50%, #e0f2fe 100%);
}
[data-testid="stSidebar"] {
    background: #0f172a;
}
[data-testid="stSidebar"] * {
    color: white !important;
}
h1,h2,h3,h4,h5,h6,p,span,label,div {
    color: #0f172a !important;
}
.hero {
    background: linear-gradient(135deg, #0f172a, #1d4ed8);
    padding: 28px;
    border-radius: 22px;
    margin-bottom: 20px;
}
.hero h1 {
    color: white !important;
    font-size: 42px;
}
.hero p {
    color: #dbeafe !important;
}
.badge {
    background: #fee2e2;
    color: #991b1b !important;
    padding: 8px 14px;
    border-radius: 999px;
    display: inline-block;
    font-weight: 800;
}
.agent-card {
    background: #eff6ff;
    border: 1px solid #93c5fd;
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 10px;
}
</style>
""", unsafe_allow_html=True)

def ensure_file():
    if not INCIDENTS_FILE.exists():
        DEFAULT_INCIDENTS.to_csv(INCIDENTS_FILE, index=False)

def load_incidents():
    ensure_file()
    df = pd.read_csv(INCIDENTS_FILE)

    required_columns = [
        "id", "title", "status", "priority", "assigned_to",
        "created", "resolved", "description", "closure_notes"
    ]

    for col in required_columns:
        if col not in df.columns:
            df[col] = ""

    return df[required_columns]

def save_incidents(df):
    df.to_csv(INCIDENTS_FILE, index=False)

def next_id(df):
    nums = []
    for i in df["id"]:
        try:
            nums.append(int(str(i).replace("INC", "")))
        except Exception:
            pass
    return f"INC{max(nums)+1:03d}" if nums else "INC001"

def filter_tickets_from_question(question, df):
    q = question.lower()
    result = df.copy()

    if "p1" in q:
        result = result[result["priority"].str.upper() == "P1"]
    if "p2" in q:
        result = result[result["priority"].str.upper() == "P2"]
    if "p3" in q:
        result = result[result["priority"].str.upper() == "P3"]
    if "p4" in q:
        result = result[result["priority"].str.upper() == "P4"]

    if "active" in q or "open" in q:
        result = result[result["status"].str.lower().isin(["open", "in progress"])]

    if "closed" in q:
        result = result[result["status"].str.lower() == "closed"]

    return result

def ai_agent(task, ticket):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": "You are an enterprise ITSM AI agent specializing in RCA, SLA analysis, incident management, ticket closure, and prevention recommendations."
            },
            {
                "role": "user",
                "content": f"""
Ticket / Ticket List:
{ticket}

Alerts:
{ALERTS.to_string(index=False)}

Prevention:
{PREVENTION.to_string(index=False)}

Task:
{task}

Generate enterprise-quality structured output.
"""
            }
        ],
        temperature=0.25,
        max_tokens=1800
    )
    return response.choices[0].message.content

incidents_df = load_incidents()

st.sidebar.title("🚨 SentinelOps ITSM")
page = st.sidebar.radio(
    "Menu",
    ["Dashboard", "Tickets", "AI Agent", "Incident Document", "Prevention Hub"]
)

st.markdown("""
<div class="hero">
<h1>SentinelOps ITSM</h1>
<p>Enterprise Ticket Management & AI Incident Prevention Platform</p>
<span class="badge">P1 Major Incident • Payment Gateway • Production</span>
</div>
""", unsafe_allow_html=True)

if page == "Dashboard":
    open_count = len(incidents_df[incidents_df["status"] != "Closed"])
    closed_count = len(incidents_df[incidents_df["status"] == "Closed"])
    p1_count = len(incidents_df[incidents_df["priority"] == "P1"])

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Open Tickets", open_count)
    c2.metric("Closed Tickets", closed_count)
    c3.metric("P1 Incidents", p1_count)
    c4.metric("SLA Risk", "94%")

    st.subheader("All Tickets")
    st.dataframe(incidents_df, use_container_width=True)

    st.subheader("Alert Timeline")
    st.dataframe(ALERTS, use_container_width=True)

elif page == "Tickets":
    st.subheader("Create Ticket")

    with st.form("create_ticket"):
        title = st.text_input("Title")
        desc = st.text_area("Description")
        priority = st.selectbox("Priority", ["P1", "P2", "P3", "P4"])
        status = st.selectbox("Status", ["Open", "In Progress", "Closed"])
        assigned = st.selectbox("Assigned To", ASSIGNEES)

        submit = st.form_submit_button("Create Ticket")

        if submit:
            new_row = {
                "id": next_id(incidents_df),
                "title": title,
                "status": status,
                "priority": priority,
                "assigned_to": assigned,
                "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "resolved": datetime.now().strftime("%Y-%m-%d %H:%M") if status == "Closed" else "",
                "description": desc,
                "closure_notes": ""
            }

            updated = pd.concat([incidents_df, pd.DataFrame([new_row])], ignore_index=True)
            save_incidents(updated)
            st.success(f"Ticket {new_row['id']} created successfully")
            st.rerun()

    st.subheader("Existing Tickets")
    incidents_df = load_incidents()
    st.dataframe(incidents_df, use_container_width=True)

    st.subheader("Update Ticket")

    if len(incidents_df) > 0:
        selected_id = st.selectbox("Select Ticket to Update", incidents_df["id"].tolist())
        selected = incidents_df[incidents_df["id"] == selected_id].iloc[0]

        assigned_index = ASSIGNEES.index(selected["assigned_to"]) if selected["assigned_to"] in ASSIGNEES else 0

        with st.form("update_ticket"):
            new_title = st.text_input("Update Title", value=selected["title"])
            new_desc = st.text_area("Update Description", value=selected["description"])

            priority_list = ["P1", "P2", "P3", "P4"]
            status_list = ["Open", "In Progress", "Closed"]

            new_priority = st.selectbox(
                "Update Priority",
                priority_list,
                index=priority_list.index(selected["priority"]) if selected["priority"] in priority_list else 0
            )

            new_status = st.selectbox(
                "Update Status",
                status_list,
                index=status_list.index(selected["status"]) if selected["status"] in status_list else 0
            )

            new_assigned = st.selectbox("Update Assigned To", ASSIGNEES, index=assigned_index)

            update_submit = st.form_submit_button("Update Ticket")

            if update_submit:
                idx = incidents_df[incidents_df["id"] == selected_id].index[0]

                incidents_df.at[idx, "title"] = new_title
                incidents_df.at[idx, "description"] = new_desc
                incidents_df.at[idx, "priority"] = new_priority
                incidents_df.at[idx, "status"] = new_status
                incidents_df.at[idx, "assigned_to"] = new_assigned

                if new_status == "Closed":
                    incidents_df.at[idx, "resolved"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                else:
                    incidents_df.at[idx, "resolved"] = ""

                save_incidents(incidents_df)
                st.success(f"Ticket {selected_id} updated successfully")
                st.rerun()

        st.subheader("Close Ticket")

        open_df = incidents_df[incidents_df["status"] != "Closed"]

        if len(open_df) > 0:
            close_id = st.selectbox("Select Ticket to Close", open_df["id"].tolist())

            closure_notes = st.text_area(
                "Closure Notes",
                placeholder="Example: Issue resolved after pausing reconciliation batch, clearing payment queue, and validating DB locks."
            )

            if st.button("Close Ticket", use_container_width=True):
                idx = incidents_df[incidents_df["id"] == close_id].index[0]

                incidents_df.at[idx, "status"] = "Closed"
                incidents_df.at[idx, "resolved"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                incidents_df.at[idx, "closure_notes"] = closure_notes

                save_incidents(incidents_df)

                st.success(f"{close_id} closed successfully")
                st.rerun()
        else:
            st.info("No open tickets available to close.")

        st.subheader("Closed Ticket Details")
        closed_df = incidents_df[incidents_df["status"] == "Closed"]
        st.dataframe(closed_df, use_container_width=True)

        st.subheader("Delete Ticket")

        delete_id = st.selectbox("Select Ticket to Delete", incidents_df["id"].tolist())

        if st.button("Delete Ticket", use_container_width=True):
            updated = incidents_df[incidents_df["id"] != delete_id].reset_index(drop=True)
            save_incidents(updated)
            st.success(f"Ticket {delete_id} deleted successfully")
            st.rerun()

elif page == "AI Agent":
    st.markdown("""
<div class="agent-card"><b>RCA Agent</b> - Performs enterprise root cause analysis.</div>
<div class="agent-card"><b>SLA Agent</b> - Predicts SLA breach risk and business impact.</div>
<div class="agent-card"><b>Prevention Agent</b> - Generates proactive recommendations.</div>
""", unsafe_allow_html=True)

    task = st.text_area(
        "Ask AI",
        value="show p1 active tickets"
    )

    if st.button("Run AI Agent", use_container_width=True):
        filtered_df = filter_tickets_from_question(task, incidents_df)

        if len(filtered_df) > 0 and (
            "show" in task.lower()
            or "list" in task.lower()
            or "display" in task.lower()
            or "tickets" in task.lower()
        ):
            st.subheader("Matching Ticket Details")
            st.dataframe(filtered_df, use_container_width=True)

            with st.spinner("AI summarizing matching tickets..."):
                output = ai_agent(
                    f"Summarize these matching tickets based on user request: {task}",
                    filtered_df.to_string(index=False)
                )

            st.subheader("AI Summary")
            st.markdown(output)

        else:
            st.subheader("All Ticket Details")
            st.dataframe(incidents_df, use_container_width=True)

            with st.spinner("AI agent analyzing tickets..."):
                output = ai_agent(task, incidents_df.to_string(index=False))

            st.subheader("AI Agent Response")
            st.markdown(output)

elif page == "Incident Document":
    ticket_id = st.selectbox("Select Ticket", incidents_df["id"].tolist(), key="doc")

    selected_df = incidents_df[incidents_df["id"] == ticket_id]
    selected = selected_df.iloc[0]

    if st.button("Generate Incident Document", use_container_width=True):
        st.subheader("Selected Ticket Details")
        st.dataframe(selected_df, use_container_width=True)

        result = ai_agent(
            "Generate complete enterprise incident management document with RCA, closure readiness, and prevention recommendations.",
            selected.to_string()
        )

        st.subheader("Incident Management Document")
        st.markdown(result)

        st.download_button(
            "Download Document",
            data=result,
            file_name=f"{ticket_id}_incident_document.txt",
            mime="text/plain"
        )

elif page == "Prevention Hub":
    st.subheader("Prevention Recommendations")
    st.dataframe(PREVENTION, use_container_width=True)

    if st.button("Generate Prevention Plan", use_container_width=True):
        result = ai_agent(
            "Generate enterprise incident-to-prevention recommendations.",
            incidents_df.to_string()
        )
        st.markdown(result)

st.caption("SentinelOps ITSM • Real AI Agent • Streamlit Enterprise App")