# SentinelOps ITSM Updated

## Changes
- Removed sidebar API connected/details
- AI Agent page shows selected ticket details in table format after clicking Run AI Agent
- Incident Document page also shows selected ticket details in table format
- Uses real AI agent through .env

## Run CMD
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python -m streamlit run app.py
