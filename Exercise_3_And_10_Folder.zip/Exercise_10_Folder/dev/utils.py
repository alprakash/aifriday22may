import hashlib
import json
import uuid
import datetime
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import streamlit as st

# ============================================================================
# 1. SECURITY & AUDIT ENGINE
# ============================================================================

SALT = "ENT_SALT_99xbc!_2026"

def hash_pii(text: str) -> str:
    """Cryptographically anonymizes high-PII strings."""
    return hashlib.sha256(f"{text}{SALT}".encode('utf-8')).hexdigest()[:12].upper()

def mask_salary(salary: float) -> str:
    """Masks financial compensation into $20k statistical bands."""
    lower_bound = int(salary // 20000) * 20000
    upper_bound = lower_bound + 20000
    return f"${lower_bound:,} - ${upper_bound:,}"

def write_audit_log(actor: str, action: str, status: str, payload_summary: dict):
    """
    Appends structured, enterprise-auditable records to session state.
    """
    if "audit_trail" not in st.session_state:
        st.session_state.audit_trail = []
        
    log_entry = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "transaction_id": f"TXN-{str(uuid.uuid4())[:8].upper()}",
        "actor_id": actor,
        "action": action,
        "status": status,
        "payload_hash": hashlib.sha256(json.dumps(payload_summary, default=str).encode()).hexdigest()[:16]
    }
    st.session_state.audit_trail.insert(0, log_entry)

# ============================================================================
# 2. MASTER REFERENCE DATASEEDING
# ============================================================================

def seed_state_data():
    if "raw_employees" not in st.session_state:
        st.session_state.raw_employees = [
            {"employee_id": "EMP-001", "full_name": "Arjun Mehta", "role": "Solution Architect", "seniority": "Principal", "location": "Bangalore", "team": "Architecture", "skills": ["Cloud", "API", "Security", "Azure"], "current_salary": 185000, "cost_rate": 180.0, "work_mode": "onsite", "performance_score": "Exceeds"},
            {"employee_id": "EMP-002", "full_name": "Priya Nair", "role": "Data Engineer", "seniority": "Senior", "location": "Hyderabad", "team": "Data & Analytics", "skills": ["Spark", "Python", "Kafka", "SQL"], "current_salary": 140000, "cost_rate": 140.0, "work_mode": "onsite", "performance_score": "Meets"},
            {"employee_id": "EMP-003", "full_name": "David Chen", "role": "DevOps Engineer", "seniority": "Senior", "location": "Singapore", "team": "Platform", "skills": ["K8s", "Terraform", "CI/CD", "AWS"], "current_salary": 160000, "cost_rate": 155.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-004", "full_name": "Fatima Al-Hassan", "role": "Security Analyst", "seniority": "Mid", "location": "Dubai", "team": "Security", "skills": ["PenTest", "SIEM", "Compliance"], "current_salary": 125000, "cost_rate": 120.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-005", "full_name": "Marcus Thompson", "role": "BA / PM", "seniority": "Senior", "location": "London", "team": "Delivery", "skills": ["Agile", "JIRA", "Stakeholder Mgmt"], "current_salary": 130000, "cost_rate": 130.0, "work_mode": "onsite", "performance_score": "Meets"},
            {"employee_id": "EMP-006", "full_name": "Yuki Tanaka", "role": "ML Engineer", "seniority": "Senior", "location": "Tokyo", "team": "Data & Analytics", "skills": ["PyTorch", "MLOps", "Python"], "current_salary": 175000, "cost_rate": 160.0, "work_mode": "remote", "performance_score": "Exceeds"},
            {"employee_id": "EMP-007", "full_name": "Ravi Shankar", "role": "Backend Developer", "seniority": "Mid", "location": "Bangalore", "team": "Engineering", "skills": ["Java", "Spring", "Microservices", "SQL"], "current_salary": 110000, "cost_rate": 95.0, "work_mode": "onsite", "performance_score": "Meets"},
            {"employee_id": "EMP-008", "full_name": "Elena Popescu", "role": "Frontend Developer", "seniority": "Mid", "location": "Bucharest", "team": "Engineering", "skills": ["React", "TypeScript", "GraphQL"], "current_salary": 105000, "cost_rate": 90.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-009", "full_name": "James Okafor", "role": "Cloud Architect", "seniority": "Principal", "location": "Lagos", "team": "Architecture", "skills": ["GCP", "Multi-Cloud", "FinOps"], "current_salary": 180000, "cost_rate": 175.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-010", "full_name": "Sofia Reyes", "role": "QA Engineer", "seniority": "Senior", "location": "Mexico City", "team": "QA", "skills": ["Selenium", "API Testing", "Performance"], "current_salary": 115000, "cost_rate": 100.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-011", "full_name": "Ankit Patel", "role": "Backend Developer", "seniority": "Junior", "location": "Bangalore", "team": "Engineering", "skills": ["Java", "Python", "SQL"], "current_salary": 75000, "cost_rate": 60.0, "work_mode": "onsite", "performance_score": "Underperforming"},
            {"employee_id": "EMP-012", "full_name": "Chloe Dubois", "role": "UX Designer", "seniority": "Mid", "location": "Paris", "team": "Design", "skills": ["Figma", "Research", "Design Systems"], "current_salary": 95000, "cost_rate": 95.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-013", "full_name": "Omar Farooq", "role": "Database Admin", "seniority": "Senior", "location": "Islamabad", "team": "Data & Analytics", "skills": ["Oracle", "PostgreSQL", "MongoDB"], "current_salary": 120000, "cost_rate": 110.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-014", "full_name": "Ingrid Berg", "role": "Scrum Master", "seniority": "Mid", "location": "Oslo", "team": "Delivery", "skills": ["Scrum", "Kanban", "Coaching"], "current_salary": 105000, "cost_rate": 105.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-015", "full_name": "Tariq Hassan", "role": "Network Engineer", "seniority": "Mid", "location": "Cairo", "team": "Platform", "skills": ["Cisco", "SD-WAN", "Zero Trust"], "current_salary": 100000, "cost_rate": 88.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-016", "full_name": "Mei Ling", "role": "Data Scientist", "seniority": "Mid", "location": "Shanghai", "team": "Data & Analytics", "skills": ["R", "Python", "Statistics", "Tableau"], "current_salary": 110000, "cost_rate": 115.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-017", "full_name": "Carlos Estrada", "role": "Solution Architect", "seniority": "Senior", "location": "Bogota", "team": "Architecture", "skills": ["AWS", "Serverless", "Event-Driven"], "current_salary": 155000, "cost_rate": 145.0, "work_mode": "remote", "performance_score": "Meets"},
            {"employee_id": "EMP-018", "full_name": "Nadia Kovacs", "role": "Business Analyst", "seniority": "Junior", "location": "Budapest", "team": "Delivery", "skills": ["Requirements", "BPMN", "SQL"], "current_salary": 70000, "cost_rate": 55.0, "work_mode": "remote", "performance_score": "Meets"}
        ]

    # Quick conversions to allow graphs
    for emp in st.session_state.raw_employees:
        # seeding allocated_pct matching workload data
        allocations = {
            "EMP-001": 145, "EMP-002": 130, "EMP-003": 125, "EMP-004": 118, "EMP-005": 112, "EMP-006": 108,
            "EMP-007": 95, "EMP-008": 88, "EMP-009": 82, "EMP-010": 45, "EMP-011": 40, "EMP-012": 38,
            "EMP-013": 35, "EMP-014": 30, "EMP-015": 28, "EMP-016": 25, "EMP-017": 22, "EMP-018": 18
        }
        emp["allocated_pct"] = allocations.get(emp["employee_id"], 100)
        emp["capacity_pct"] = 100

    if "raw_projects" not in st.session_state:
        st.session_state.raw_projects = [
            {"project_id": "PRJ-5001", "client_id": "Nexus Corp", "target_margin_pct": 35.0, "max_hourly_rate": 180.0, "required_skills": ["Cloud", "Azure", "API"]},
            {"project_id": "PRJ-5002", "client_id": "Vanguard Finance", "target_margin_pct": 40.0, "max_hourly_rate": 220.0, "required_skills": ["Python", "PyTorch", "MLOps"]},
            {"project_id": "PRJ-5003", "client_id": "Apex Retail", "target_margin_pct": 30.0, "max_hourly_rate": 140.0, "required_skills": ["React", "TypeScript"]},
            {"project_id": "PRJ-5004", "client_id": "APEX Core Banking", "target_margin_pct": 35.0, "max_hourly_rate": 250.0, "required_skills": ["Spark", "Python", "Kafka"]}
        ]

    if "pending_approvals" not in st.session_state:
        st.session_state.pending_approvals = []

    if "governance_note" not in st.session_state:
        st.session_state.governance_note = {
            "title": "AI Governance Framework: APEX Staffing & Capacity Intelligence Model",
            "date": "2026-05-22",
            "author": "Compliance Committee & Chief Risk Officer",
            "status": "APPROVED WITH CONTINGENCY",
            "use_case_description": "The AI model parses project skill requirements, employee technical capabilities, salary bands, and performance metrics to generate optimized resource matches and highlight delivery margin risks.",
            "data_sensitivity_pii": "HIGH. Contains full names, exact salaries, performance reviews, and locations of individual employees.",
            "mitigation_anonymization": "Mandatory. Cryptographic SHA-256 PII hashing (salted with 'ENT_SALT_99xbc!_2026') maps real employee IDs to unique 12-char hashes. Salaries are masked into $20k statistical bands. Original identifiers are blocked from leaving the secure execution perimeter.",
            "guardrail_thresholds": "Margin limits are hardlocked at 25% by default. Underperforming candidates are barred from recommendations unless delivery lead checks the policy override and HR manually signs off.",
            "human_in_the_loop": "100% required. AI matches are created as non-binding 'Proposals' in an execution review queue. No automated scheduling is executed until a Delivery Lead authorizes production release.",
            "governance_signatures": [
                {"role": "Lead Architect", "status": "Signed", "timestamp": "2026-05-20T14:22:00Z"},
                {"role": "Compliance Auditor", "status": "Signed", "timestamp": "2026-05-21T09:10:00Z"},
                {"role": "VP HR Operations", "status": "Pending Final Release Sign-off", "timestamp": ""}
            ]
        }

# ============================================================================
# 3. PLOTLY CHART BUILDERS (MATCHING OPTIMA CSS THEME)
# ============================================================================

CHART_THEME = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(14,18,36,0.6)",
    font=dict(family="Inter, sans-serif", color="#8A9BBE", size=11),
    colorway=["#4F8EF7", "#00D4C8", "#F5A623", "#FF4D6A", "#8B5CF6", "#00C896"],
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", zeroline=False, linecolor="rgba(255,255,255,0.08)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", zeroline=False, linecolor="rgba(255,255,255,0.08)"),
    margin=dict(l=10, r=10, t=30, b=10),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(79,142,247,0.2)", borderwidth=1),
)

def allocation_gauge_chart(df):
    df_sorted = df.sort_values("allocated_pct", ascending=True)
    def color_for_pct(pct):
        if pct > 120: return "#FF4D6A"
        elif pct > 100: return "#F5A623"
        elif pct >= 80: return "#00C896"
        else: return "#4F8EF7"
    colors = [color_for_pct(p) for p in df_sorted["allocated_pct"]]
    short_names = [n.split()[0] + " " + n.split()[1][0] + "." for n in df_sorted["full_name"]]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=df_sorted["allocated_pct"],
        y=short_names,
        orientation="h",
        marker_color=colors,
        text=[f"{p}%" for p in df_sorted["allocated_pct"]],
        textposition="outside",
        textfont=dict(size=10, color="#8A9BBE"),
        hovertemplate="<b>%{y}</b><br>Allocation: %{x}%<extra></extra>",
    ))
    fig.add_vline(x=100, line_dash="dash", line_color="rgba(255,255,255,0.25)", line_width=1.5,
                  annotation_text="100% Capacity", annotation_font_size=9,
                  annotation_font_color="rgba(255,255,255,0.4)", annotation_position="top left")
    fig.add_vline(x=120, line_dash="dot", line_color="rgba(255,77,106,0.4)", line_width=1)
    
    fig.update_layout(
        **CHART_THEME, height=480,
        xaxis=dict(**CHART_THEME["xaxis"], range=[0, 180], title="Current Allocation %"),
        yaxis=dict(**CHART_THEME["yaxis"], tickfont=dict(size=9))
    )
    return fig

def team_utilization_donut(df):
    buckets = {"Overloaded (>120%)": 0, "At Risk (101-120%)": 0, "Optimal (80-100%)": 0, "Underutilized (<80%)": 0}
    for _, r in df.iterrows():
        p = r["allocated_pct"]
        if p > 120: buckets["Overloaded (>120%)"] += 1
        elif p > 100: buckets["At Risk (101-120%)"] += 1
        elif p >= 80: buckets["Optimal (80-100%)"] += 1
        else: buckets["Underutilized (<80%)"] += 1

    fig = go.Figure(go.Pie(
        labels=list(buckets.keys()),
        values=list(buckets.values()),
        hole=0.6,
        marker=dict(colors=["#FF4D6A", "#F5A623", "#00C896", "#4F8EF7"],
                    line=dict(color="rgba(0,0,0,0)", width=0)),
        textfont=dict(size=10, color="#E8EDF8"),
        hovertemplate="<b>%{label}</b><br>Count: %{value}<br>Share: %{percent}<extra></extra>",
    ))
    fig.add_annotation(text=f"<b style='font-size:22px; color:#E8EDF8'>{len(df)}</b><br><span style='font-size:10px; color:#8A9BBE'>Resources</span>",
                       x=0.5, y=0.5, showarrow=False)
    pie_theme = {k: v for k, v in CHART_THEME.items() if k not in ["xaxis", "yaxis", "legend"]}
    fig.update_layout(
        **pie_theme, height=280, showlegend=True,
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(79,142,247,0.2)", borderwidth=1, orientation="v", x=1.02, y=0.5)
    )
    return fig

def capacity_demand_chart():
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
    cap_demand_df = pd.DataFrame({
        "Month": months,
        "Available_Hours": [2800, 2600, 2900, 2750, 2850, 2700],
        "Demanded_Hours":  [3350, 3480, 3620, 3200, 2950, 2650],
        "Critical_Path_Hours": [1200, 1350, 1480, 1300, 1100, 950],
    })

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=cap_demand_df["Month"], y=cap_demand_df["Available_Hours"],
        mode="lines+markers", name="Available Capacity",
        line=dict(color="#00C896", width=2.5),
        marker=dict(size=7, symbol="circle"),
        fill="tozeroy", fillcolor="rgba(0,200,150,0.05)",
        hovertemplate="<b>Available</b>: %{y:,} hrs<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=cap_demand_df["Month"], y=cap_demand_df["Demanded_Hours"],
        mode="lines+markers", name="Demand (All Work)",
        line=dict(color="#FF4D6A", width=2.5),
        marker=dict(size=7, symbol="diamond"),
        hovertemplate="<b>Demand</b>: %{y:,} hrs<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=cap_demand_df["Month"], y=cap_demand_df["Critical_Path_Hours"],
        mode="lines+markers", name="Critical Path Demand",
        line=dict(color="#F5A623", width=2, dash="dot"),
        marker=dict(size=6, symbol="triangle-up"),
        hovertemplate="<b>Critical Path</b>: %{y:,} hrs<extra></extra>",
    ))
    
    # Shade gap
    fig.add_trace(go.Scatter(
        x=list(cap_demand_df["Month"]) + list(reversed(cap_demand_df["Month"])),
        y=list(cap_demand_df["Demanded_Hours"]) + list(reversed(cap_demand_df["Available_Hours"])),
        fill="toself", fillcolor="rgba(255,77,106,0.04)",
        line=dict(width=0), showlegend=False, hoverinfo="skip",
        name="Capacity Gap",
    ))
    
    theme_no_legend_yaxis = {k: v for k, v in CHART_THEME.items() if k not in ["legend", "yaxis"]}
    fig.update_layout(
        **theme_no_legend_yaxis, height=320,
        yaxis=dict(**CHART_THEME["yaxis"], title="Hours"),
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(79,142,247,0.2)", borderwidth=1, orientation="h", y=1.12, x=0.1)
    )
    return fig

def workload_heatmap(df):
    # Simulated 12 sprints for the employees
    sprints = [f"S{i:02d}" for i in range(1, 13)]
    names = [n.split()[0] + " " + n.split()[1][0] + "." for n in df["full_name"]]
    
    # Generate workload matching their base allocated_pct with small variations
    z = []
    for _, r in df.iterrows():
        base = r["allocated_pct"]
        z.append([int(base + np.random.randint(-10, 10)) for _ in range(12)])

    fig = go.Figure(go.Heatmap(
        z=z, x=sprints, y=names,
        colorscale=[
            [0.0,  "#1A3B6B"],
            [0.25, "#4F8EF7"],
            [0.5,  "#00C896"],
            [0.75, "#F5A623"],
            [1.0,  "#FF4D6A"],
        ],
        zmid=100, zmin=0, zmax=165,
        text=[[f"{v}%" for v in row] for row in z],
        texttemplate="%{text}", textfont=dict(size=8),
        hovertemplate="<b>%{y}</b> | %{x}<br>Allocation: %{z}%<extra></extra>",
        colorbar=dict(
            title=dict(text="Alloc %", font=dict(size=10, color="#8A9BBE")),
            tickfont=dict(color="#8A9BBE", size=9),
            len=0.8,
        ),
    ))
    fig.update_layout(
        **CHART_THEME, height=480,
        xaxis=dict(**CHART_THEME["xaxis"], title="Sprint Node"),
        yaxis=dict(**CHART_THEME["yaxis"], tickfont=dict(size=9))
    )
    return fig

def cost_efficiency_scatter(df):
    fig = go.Figure()
    teams = df["team"].unique()
    color_map = {t: c for t, c in zip(teams, ["#4F8EF7", "#00D4C8", "#F5A623", "#FF4D6A", "#8B5CF6", "#00C896", "#F97316"])}

    for team in teams:
        tdf = df[df["team"] == team]
        efficiency = tdf["allocated_pct"].apply(lambda x: 100 - abs(100 - x))
        fig.add_trace(go.Scatter(
            x=tdf["cost_rate"], y=tdf["allocated_pct"],
            mode="markers+text", name=team,
            text=[n.split()[0] for n in tdf["full_name"]],
            textposition="top center",
            textfont=dict(size=9),
            marker=dict(
                size=[e/4 + 8 for e in efficiency],
                color=color_map.get(team, "#4F8EF7"),
                opacity=0.8,
                line=dict(width=1, color="rgba(255,255,255,0.15)"),
            ),
            hovertemplate="<b>%{text}</b><br>Hourly Rate: $%{x}<br>Allocation: %{y}%<extra></extra>",
        ))

    fig.add_hrect(y0=80, y1=100, fillcolor="rgba(0,200,150,0.05)", line_width=0,
                  annotation_text="Optimal Utilization Zone", annotation_font_size=9,
                  annotation_font_color="rgba(0,200,150,0.4)")
    fig.add_hline(y=100, line_dash="dash", line_color="rgba(255,255,255,0.2)")
    
    theme_no_axes = {k: v for k, v in CHART_THEME.items() if k not in ["xaxis", "yaxis"]}
    fig.update_layout(
        **theme_no_axes, height=360,
        xaxis=dict(**CHART_THEME["xaxis"], title="Hourly Billing/Cost Rate (USD)"),
        yaxis=dict(**CHART_THEME["yaxis"], title="Allocation Percentage")
    )
    return fig

def rebalancing_waterfall(df):
    overloaded = df[df["allocated_pct"] > 100].head(4)
    underutil  = df[df["allocated_pct"] < 60].head(4)

    before_over = list(overloaded["allocated_pct"])
    after_over  = [min(p - 30, 100) for p in before_over]
    before_under = list(underutil["allocated_pct"])
    after_under  = [min(p + 35, 95) for p in before_under]

    fig = make_subplots(rows=1, cols=2,
                        subplot_titles=["Overallocated Rebalancing Impact",
                                        "Underutilized Redeployment Uplift"])

    names_over  = [n.split()[0] for n in overloaded["full_name"]]
    names_under = [n.split()[0] for n in underutil["full_name"]]

    fig.add_trace(go.Bar(name="Current", x=names_over, y=before_over,
                         marker_color="#FF4D6A", marker_line_width=0), row=1, col=1)
    fig.add_trace(go.Bar(name="After Balance", x=names_over, y=after_over,
                         marker_color="#00C896", marker_line_width=0), row=1, col=1)
    
    fig.add_trace(go.Bar(name="Current", x=names_under, y=before_under,
                         marker_color="#4F8EF7", marker_line_width=0, showlegend=False), row=1, col=2)
    fig.add_trace(go.Bar(name="After Redeploy", x=names_under, y=after_under,
                         marker_color="#00D4C8", marker_line_width=0, showlegend=False), row=1, col=2)

    theme_no_yaxis_legend = {k: v for k, v in CHART_THEME.items() if k not in ["yaxis", "legend"]}
    fig.update_layout(
        **theme_no_yaxis_legend, height=320, barmode="group",
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(79,142,247,0.2)", borderwidth=1, orientation="h", y=1.1, x=0.3),
        yaxis=dict(**CHART_THEME["yaxis"], title="Allocation %", range=[0, 175]),
        yaxis2=dict(**CHART_THEME["yaxis"], title="Allocation %")
    )
    for ax in ["xaxis", "xaxis2"]:
        fig.update_layout(**{ax: dict(**CHART_THEME["xaxis"])})
    return fig

def skills_gap_radar():
    skills_gap_df = pd.DataFrame([
        ("Cloud Architecture", "Azure", "Critical", 2, 0.5),
        ("Data Engineering", "Kafka", "High", 3, 1.0),
        ("Security", "Zero Trust", "High", 2, 0.5),
        ("ML/AI", "MLOps", "Medium", 2, 1.5),
        ("DevOps", "GitOps", "Medium", 3, 2.0),
        ("Frontend", "React", "Low", 2, 2.5)
    ], columns=["domain", "skill", "gap_severity", "needed", "available"])

    labels = [f"{r['domain']}\n({r['skill']})" for _, r in skills_gap_df.iterrows()]
    needed    = list(skills_gap_df["needed"])
    available = list(skills_gap_df["available"])

    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=needed + [needed[0]], theta=labels + [labels[0]],
        name="Required FTEs", fill="toself",
        fillcolor="rgba(255,77,106,0.1)", line=dict(color="#FF4D6A", width=2),
    ))
    fig.add_trace(go.Scatterpolar(
        r=available + [available[0]], theta=labels + [labels[0]],
        name="Available FTEs", fill="toself",
        fillcolor="rgba(79,142,247,0.1)", line=dict(color="#4F8EF7", width=2),
    ))
    fig.update_layout(
        **CHART_THEME, height=360,
        polar=dict(
            bgcolor="rgba(14,18,36,0.6)",
            radialaxis=dict(visible=True, range=[0, 4], gridcolor="rgba(255,255,255,0.06)",
                           tickfont=dict(size=8, color="#4A5568")),
            angularaxis=dict(gridcolor="rgba(255,255,255,0.06)", tickfont=dict(size=9, color="#8A9BBE")),
        ),
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(79,142,247,0.2)", borderwidth=1, orientation="h", y=-0.15, x=0.2)
    )
    return fig
