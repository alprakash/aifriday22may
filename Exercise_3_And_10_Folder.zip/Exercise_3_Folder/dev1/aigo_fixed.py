"""
AIGO — AI-Integrated Governance & Optimization Platform
Enterprise Staffing Intelligence with Full Compliance Architecture

Production Architecture:
  • Role-Based Access Control (RBAC) — 4 roles
  • PII Anonymization Middleware before any AI inference
  • Deterministic Guardrail Engine with policy ledger
  • Human-in-the-Loop (HITL) approval pipeline
  • Immutable append-only audit trail (Snowflake-ready schema)
  • Governance Decision Note + Data Flow Model
  • AI Inference via Anthropic Claude API (claude-sonnet-4-20250514)
  • Real-time margin projection & skill-match scoring

FIXES APPLIED (v1.1):
  [FIX-01] skills_html in candidate cards now looks up the real employee's full
           skill set via _original_id instead of hardcoding raw_employees[0].
  [FIX-02] AI response panel no longer double-renders (removed duplicate pre+div).
  [FIX-03] call_claude_api parses error JSON and returns a clean, user-friendly
           message instead of raw {"type":"error",...} strings.
  [FIX-04] All st.markdown HTML f-strings audited — no bare < / > characters that
           Streamlit could interpret as raw HTML escaping.
"""

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import streamlit as st
import pandas as pd
import hashlib
import json
import uuid
import datetime
import time
import requests

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 0 — PAGE CONFIG (must be first Streamlit call)
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="AIGO · AI Governance Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — CUSTOM CSS
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

:root {
    --ink: #0D0F1A; --ink-muted: #4A4E6A; --surface: #F5F5F8;
    --border: #E1E2EA; --accent: #2563EB; --accent-soft: #EFF4FF;
    --success: #059669; --success-soft: #ECFDF5;
    --danger: #DC2626; --danger-soft: #FEF2F2;
    --warn: #D97706; --warn-soft: #FFFBEB;
    --mono: 'Space Mono', monospace;
}

section[data-testid="stSidebar"] {
    background: #0D0F1A !important;
    border-right: 1px solid #1E2035;
}
section[data-testid="stSidebar"] * { color: #C8CADE !important; }
section[data-testid="stSidebar"] .stSelectbox label,
section[data-testid="stSidebar"] h2,
section[data-testid="stSidebar"] h3 {
    color: #7B82A8 !important; font-size: 11px !important;
    letter-spacing: 0.08em; text-transform: uppercase; font-weight: 600 !important;
}

.metric-card {
    background: white; border: 1px solid var(--border); border-radius: 12px;
    padding: 20px 24px; position: relative; overflow: hidden;
}
.metric-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0;
    height: 3px; background: var(--accent);
}
.metric-card.success::before { background: var(--success); }
.metric-card.danger::before  { background: var(--danger); }
.metric-card.warn::before    { background: var(--warn); }
.metric-label {
    font-size: 11px; font-weight: 600; letter-spacing: 0.07em;
    text-transform: uppercase; color: var(--ink-muted); margin-bottom: 8px;
}
.metric-value {
    font-family: var(--mono); font-size: 28px; font-weight: 700;
    color: var(--ink); line-height: 1;
}
.metric-sub { font-size: 12px; color: var(--ink-muted); margin-top: 4px; }

.section-label {
    display: inline-flex; align-items: center; gap: 8px;
    font-size: 11px; font-weight: 700; letter-spacing: 0.1em;
    text-transform: uppercase; color: var(--accent);
    background: var(--accent-soft); padding: 4px 12px;
    border-radius: 20px; margin-bottom: 12px;
}

.candidate-card {
    background: white; border: 1px solid var(--border); border-radius: 12px;
    padding: 16px 20px; margin-bottom: 12px; transition: box-shadow 0.15s;
}
.candidate-card:hover { box-shadow: 0 4px 16px rgba(37,99,235,0.08); border-color: #BAC8FF; }
.candidate-card.top-pick { border-color: var(--accent); border-width: 1.5px; background: #FAFBFF; }

.skill-badge {
    display: inline-block; font-size: 11px; font-weight: 600;
    padding: 3px 10px; border-radius: 20px; margin: 2px 3px 2px 0;
    background: var(--surface); color: var(--ink-muted); border: 1px solid var(--border);
}
.skill-badge.match { background: var(--accent-soft); color: var(--accent); border-color: #BAC8FF; }

.chip { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 20px; }
.chip.exceeds { background: var(--success-soft); color: var(--success); }
.chip.meets   { background: var(--surface);      color: var(--ink-muted); }
.chip.under   { background: var(--danger-soft);  color: var(--danger); }

.guardrail-item {
    display: flex; align-items: flex-start; gap: 12px; padding: 14px 16px;
    border-radius: 10px; margin-bottom: 8px; border: 1px solid transparent;
}
.guardrail-item.pass    { background: var(--success-soft); border-color: #A7F3D0; }
.guardrail-item.fail    { background: var(--danger-soft);  border-color: #FECACA; }
.guardrail-item.pending { background: var(--surface);      border-color: var(--border); }
.guardrail-icon  { font-size: 16px; margin-top: 1px; }
.guardrail-title { font-weight: 600; font-size: 13px; color: var(--ink); }
.guardrail-desc  { font-size: 12px; color: var(--ink-muted); margin-top: 2px; }

/* ── AI Output panel — FIX-02: single clean container, no double render ── */
.ai-panel {
    background: #FAFBFF; border: 1px solid #BAC8FF; border-radius: 12px; padding: 20px 24px;
}
.ai-panel-body {
    background: white; border: 1px solid var(--border); border-radius: 8px;
    padding: 16px; font-family: var(--mono); font-size: 12px; line-height: 1.75;
    white-space: pre-wrap; word-break: break-word; color: var(--ink);
    max-height: 520px; overflow-y: auto;
}

/* ── Error banner ── */
.error-banner {
    background: var(--danger-soft); border: 1px solid #FECACA; border-left: 4px solid var(--danger);
    border-radius: 0 10px 10px 0; padding: 14px 18px; border-radius: 10px;
}
.error-banner .err-title { font-weight: 700; color: var(--danger); font-size: 13px; margin-bottom: 4px; }
.error-banner .err-body  { font-size: 12px; color: #7F1D1D; }

.gov-note {
    background: white; border: 1px solid var(--border); border-left: 4px solid var(--accent);
    border-radius: 0 12px 12px 0; padding: 20px 24px;
}
.gov-note h4 {
    font-size: 13px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.06em; color: var(--accent); margin-bottom: 10px;
}

.proposal-card {
    background: white; border: 1px solid var(--border); border-radius: 10px;
    padding: 14px 18px; margin-bottom: 10px;
    display: flex; justify-content: space-between; align-items: center;
}
.proposal-id   { font-family: var(--mono); font-size: 13px; font-weight: 700; color: var(--accent); }
.proposal-meta { font-size: 12px; color: var(--ink-muted); margin-top: 3px; }

.flow-step {
    display: flex; align-items: center; gap: 10px; padding: 10px 14px;
    border-radius: 8px; background: var(--surface); border: 1px solid var(--border);
    font-size: 12px; font-weight: 600; color: var(--ink-muted);
}
.flow-step.active { background: var(--accent-soft); border-color: #BAC8FF; color: var(--accent); }
.flow-arrow { text-align: center; color: var(--border); font-size: 18px; padding: 2px 0; }

div[data-testid="stButton"] > button { font-family: 'DM Sans', sans-serif; font-weight: 600; border-radius: 8px; }
div[data-testid="metric-container"] { background: white; border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; }
.stTabs [data-baseweb="tab"] { font-family: 'DM Sans', sans-serif; font-weight: 500; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — SECURITY & AUDIT CORE ENGINE
# ─────────────────────────────────────────────────────────────────────────────

ENTERPRISE_SALT   = "AIGO_ENT_SALT_2026_xK9!mR"
ANTHROPIC_MODEL   = "claude-sonnet-4-20250514"
ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"


def hash_pii(text: str) -> str:
    """SHA-256 PII anonymization — 12-char hex token."""
    return hashlib.sha256(f"{text}{ENTERPRISE_SALT}".encode()).hexdigest()[:12].upper()


def mask_salary(salary: float) -> str:
    """Bucket salary into $20k statistical bands for AI context."""
    lb = int(salary // 20_000) * 20_000
    return f"${lb:,}–${lb + 20_000:,}"


def write_audit_log(actor: str, action: str, status: str, payload: dict, details: str = ""):
    """Append immutable record to session audit ledger."""
    if "audit_trail" not in st.session_state:
        st.session_state.audit_trail = []
    entry = {
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "txn_id":        str(uuid.uuid4()),
        "actor":         actor,
        "action":        action,
        "status":        status,
        "details":       details,
        "payload_hash":  hashlib.sha256(json.dumps(payload, default=str).encode()).hexdigest()[:16],
    }
    st.session_state.audit_trail.insert(0, entry)
    return entry


# ── FIX-03: parse error JSON and return human-friendly messages ──────────────
def _friendly_api_error(status_code: int, body: str) -> str:
    """
    Convert raw Anthropic error JSON into a readable one-liner.
    Handles credit balance, auth, rate-limit, and generic errors.
    """
    try:
        data = json.loads(body)
        msg = data.get("error", {}).get("message", body)
    except Exception:
        msg = body[:300]

    if status_code == 400 and "credit balance" in msg.lower():
        return (
            "⚠️ API Credit Balance Insufficient\n\n"
            "Your Anthropic account has no remaining credits.\n"
            "Resolution → visit console.anthropic.com › Plans & Billing to top up.\n\n"
            "Running in DEMO MODE until credits are restored."
        )
    if status_code == 401:
        return (
            "🔑 Authentication Failed (HTTP 401)\n\n"
            "The API key provided is invalid or has been revoked.\n"
            "Resolution → check the key in the sidebar matches your Anthropic console key."
        )
    if status_code == 429:
        return (
            "⏱ Rate Limit Reached (HTTP 429)\n\n"
            f"Anthropic returned: {msg}\n"
            "Resolution → wait a moment and re-run, or upgrade your usage tier."
        )
    if status_code == 529:
        return (
            "🔧 Anthropic API Overloaded (HTTP 529)\n\n"
            "The API is temporarily at capacity. This is not an account issue.\n"
            "Resolution → retry in 30–60 seconds."
        )
    return f"API Error (HTTP {status_code})\n\n{msg}"


def call_claude_api(system_prompt: str, user_message: str, api_key: str) -> tuple[str, bool]:
    """
    Route anonymized payload to Claude for AI inference.
    PII is stripped BEFORE this function is ever called.

    Returns:
        (response_text, is_error)
        is_error=True means the caller should render an error banner, not a success panel.
    """
    headers = {
        "x-api-key":           api_key,
        "anthropic-version":   "2023-06-01",
        "content-type":        "application/json",
    }
    body = {
        "model":      ANTHROPIC_MODEL,
        "max_tokens": 1000,
        "system":     system_prompt,
        "messages":   [{"role": "user", "content": user_message}],
    }
    try:
        resp = requests.post(ANTHROPIC_API_URL, headers=headers, json=body, timeout=30, verify=False)
        if not resp.ok:
            friendly = _friendly_api_error(resp.status_code, resp.text)
            return friendly, True
        data = resp.json()
        return data["content"][0]["text"], False

    except requests.exceptions.Timeout:
        return (
            "⏰ Request Timed Out\n\n"
            "The Claude API did not respond within 30 seconds.\n"
            "Resolution → check your internet connection and retry.", True
        )
    except requests.exceptions.ConnectionError:
        return (
            "🌐 Connection Error\n\n"
            "Could not reach api.anthropic.com.\n"
            "Resolution → check your network or proxy settings.", True
        )
    except Exception as e:
        return f"Unexpected Error\n\n{str(e)}", True


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — REFERENCE DATA (Seeded Once Per Session)
# ─────────────────────────────────────────────────────────────────────────────

if "raw_employees" not in st.session_state:
    st.session_state.raw_employees = [
        {"employee_id": "EMP-00101", "full_name": "Sarah Connor",  "dept": "Engineering", "current_salary": 145_000, "skills_tags": ["Python", "Kubernetes", "Data Architecture", "Apache Spark"],   "performance_score": "Exceeds",        "yoe": 9,  "utilization_pct": 72, "last_project": "PRJ-5001"},
        {"employee_id": "EMP-00102", "full_name": "James Smith",   "dept": "Frontend",    "current_salary": 115_000, "skills_tags": ["React", "TypeScript", "Node.js", "GraphQL"],                    "performance_score": "Meets",          "yoe": 5,  "utilization_pct": 88, "last_project": "PRJ-5003"},
        {"employee_id": "EMP-00103", "full_name": "Elena Rostova", "dept": "AI/ML",       "current_salary": 160_000, "skills_tags": ["Python", "PyTorch", "LLMOps", "RLHF", "Kubernetes"],            "performance_score": "Exceeds",        "yoe": 11, "utilization_pct": 65, "last_project": "PRJ-5002"},
        {"employee_id": "EMP-00104", "full_name": "David Miller",  "dept": "Backend",     "current_salary": 95_000,  "skills_tags": ["Java", "Spring Boot", "PostgreSQL", "Kafka"],                   "performance_score": "Meets",          "yoe": 4,  "utilization_pct": 91, "last_project": "PRJ-5001"},
        {"employee_id": "EMP-00105", "full_name": "Amir Khan",     "dept": "Platform",    "current_salary": 130_000, "skills_tags": ["Go", "Kubernetes", "gRPC", "Terraform"],                        "performance_score": "Underperforming","yoe": 6,  "utilization_pct": 55, "last_project": "PRJ-5003"},
        {"employee_id": "EMP-00106", "full_name": "Priya Nair",    "dept": "AI/ML",       "current_salary": 155_000, "skills_tags": ["Python", "TensorFlow", "MLOps", "LLMOps", "Data Architecture"], "performance_score": "Exceeds",        "yoe": 8,  "utilization_pct": 78, "last_project": "PRJ-5002"},
        {"employee_id": "EMP-00107", "full_name": "Chris Okafor",  "dept": "Engineering", "current_salary": 108_000, "skills_tags": ["Python", "React", "FastAPI", "PostgreSQL"],                     "performance_score": "Meets",          "yoe": 5,  "utilization_pct": 82, "last_project": "PRJ-5001"},
    ]

if "raw_projects" not in st.session_state:
    st.session_state.raw_projects = [
        {"project_id": "PRJ-5001", "client_id": "Nexus Corp",      "industry": "FinTech",    "target_margin_pct": 35.0, "max_hourly_rate": 180.0, "required_skills": ["Python", "Kubernetes"],                    "duration_weeks": 12, "headcount_needed": 2, "status": "Active"},
        {"project_id": "PRJ-5002", "client_id": "Vanguard Finance", "industry": "Banking",    "target_margin_pct": 40.0, "max_hourly_rate": 220.0, "required_skills": ["Python", "PyTorch", "LLMOps"],             "duration_weeks": 20, "headcount_needed": 1, "status": "Active"},
        {"project_id": "PRJ-5003", "client_id": "Apex Retail",      "industry": "eCommerce",  "target_margin_pct": 30.0, "max_hourly_rate": 140.0, "required_skills": ["React", "TypeScript"],                     "duration_weeks": 8,  "headcount_needed": 3, "status": "Active"},
        {"project_id": "PRJ-5004", "client_id": "Stratos Health",   "industry": "HealthTech", "target_margin_pct": 38.0, "max_hourly_rate": 195.0, "required_skills": ["Python", "Data Architecture", "Apache Spark"], "duration_weeks": 16, "headcount_needed": 2, "status": "Pending"},
    ]

for _key in ("pending_approvals", "audit_trail", "approved_history", "rejected_history", "governance_notes"):
    if _key not in st.session_state:
        st.session_state[_key] = []

# Build a fast lookup map: employee_id → employee dict  (used in FIX-01)
EMPLOYEE_LOOKUP = {e["employee_id"]: e for e in st.session_state.raw_employees}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("""
    <div style='padding: 8px 0 24px 0;'>
        <div style='font-family: Space Mono, monospace; font-size: 18px; font-weight: 700;
                    color: #E8EAFF; letter-spacing: -0.5px;'>AIGO</div>
        <div style='font-size: 11px; color: #5A6080; margin-top: 3px; letter-spacing: 0.05em;'>
            AI GOVERNANCE PLATFORM
        </div>
        <div style='margin-top: 10px; display: inline-flex; align-items: center; gap: 6px;
                    background: #1A1D30; border-radius: 6px; padding: 5px 10px;'>
            <div style='width: 7px; height: 7px; border-radius: 50%; background: #34D399;'></div>
            <span style='font-size: 11px; color: #34D399; font-weight: 600;'>2026-PROD-EAST</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("**IAM — ACTIVE ROLE**")
    user_role = st.selectbox(
        "Session Identity",
        ["Delivery_Lead", "HR_Manager", "Compliance_Auditor", "Executive_Sponsor"],
        label_visibility="collapsed",
    )

    role_badges = {
        "Delivery_Lead":      ("🚀", "Full inference + HITL approval"),
        "HR_Manager":         ("👤", "Raw PII + performance records"),
        "Compliance_Auditor": ("📋", "Audit trail + governance log"),
        "Executive_Sponsor":  ("📊", "KPI dashboard + analytics"),
    }
    icon, desc = role_badges[user_role]
    st.markdown(f"""
    <div style='background:#1A1D30;border-radius:8px;padding:12px;margin-top:4px;'>
        <div style='font-size:20px;margin-bottom:4px;'>{icon}</div>
        <div style='font-size:11px;color:#7B82A8;'>{desc}</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**ANTHROPIC API KEY**")
    api_key_input = st.text_input(
        "Key (for AI inference)", type="password", placeholder="sk-ant-...",
        label_visibility="collapsed",
        help="Required only for Delivery_Lead AI inference. Other views work without it.",
    )
    if api_key_input:
        st.markdown('<div style="font-size:11px;color:#34D399;">✓ Key loaded — inference enabled</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div style="font-size:11px;color:#F59E0B;">⚠ No key — demo mode active</div>', unsafe_allow_html=True)

    st.markdown("---")
    pending_count  = len(st.session_state.pending_approvals)
    audit_count    = len(st.session_state.audit_trail)
    approved_count = len(st.session_state.approved_history)
    st.markdown("**SESSION TELEMETRY**")
    st.markdown(f"""
    <div style='display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px;'>
        <div style='background:#1A1D30;border-radius:8px;padding:10px;text-align:center;'>
            <div style='font-family:Space Mono,monospace;font-size:20px;color:#818CF8;'>{audit_count}</div>
            <div style='font-size:10px;color:#5A6080;margin-top:2px;'>Audit Events</div>
        </div>
        <div style='background:#1A1D30;border-radius:8px;padding:10px;text-align:center;'>
            <div style='font-family:Space Mono,monospace;font-size:20px;color:#F59E0B;'>{pending_count}</div>
            <div style='font-size:10px;color:#5A6080;margin-top:2px;'>Pending HITL</div>
        </div>
        <div style='background:#1A1D30;border-radius:8px;padding:10px;text-align:center;'>
            <div style='font-family:Space Mono,monospace;font-size:20px;color:#34D399;'>{approved_count}</div>
            <div style='font-size:10px;color:#5A6080;margin-top:2px;'>Approved</div>
        </div>
        <div style='background:#1A1D30;border-radius:8px;padding:10px;text-align:center;'>
            <div style='font-family:Space Mono,monospace;font-size:20px;color:#F87171;'>{len(st.session_state.rejected_history)}</div>
            <div style='font-size:10px;color:#5A6080;margin-top:2px;'>Rejected</div>
        </div>
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — MAIN HEADER
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<div style='border-bottom: 1px solid #E1E2EA; padding-bottom: 20px; margin-bottom: 28px;'>
    <h1 style='font-family: DM Sans, sans-serif; font-size: 26px; font-weight: 700;
               color: #0D0F1A; margin: 0;'>
        🛡️ AI-Integrated Governance &amp; Staffing Optimization
    </h1>
    <p style='color: #4A4E6A; margin: 6px 0 0 0; font-size: 14px;'>
        Enterprise compliance framework · Anthropic Claude powered inference · Full HITL pipeline
    </p>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 — ROLE: COMPLIANCE AUDITOR
# ─────────────────────────────────────────────────────────────────────────────

if user_role == "Compliance_Auditor":
    write_audit_log("Compliance_Auditor", "VIEW_AUDIT_TRAIL", "SUCCESS", {}, "Auditor accessed immutable ledger")

    st.markdown('<div class="section-label">📋 Immutable Governance Audit Ledger</div>', unsafe_allow_html=True)
    st.caption("Append-only record. In production: AWS CloudWatch / Snowflake append-only table. All entries are hashed and timestamped.")

    tab1, tab2, tab3 = st.tabs(["🔍 Audit Trail", "📜 Governance Decision Notes", "🔐 Anonymization Proof"])

    with tab1:
        if st.session_state.audit_trail:
            st.markdown("""
            <div style='display:grid;grid-template-columns:170px 1fr 140px 100px 90px;gap:12px;
                        padding:8px 0;border-bottom:2px solid #E1E2EA;font-size:11px;font-weight:700;
                        letter-spacing:0.06em;text-transform:uppercase;color:#4A4E6A;'>
                <div>Timestamp (UTC)</div><div>Action</div><div>Actor</div>
                <div>Status</div><div>Payload Hash</div>
            </div>""", unsafe_allow_html=True)

            for entry in st.session_state.audit_trail:
                ts = entry["timestamp_utc"][:19].replace("T", " ")
                status = entry["status"]
                status_color = "#DC2626" if "VIOLATION" in status or "ERROR" in status else ("#D97706" if "WARN" in status else "#059669")
                st.markdown(f"""
                <div style='display:grid;grid-template-columns:170px 1fr 140px 100px 90px;gap:12px;
                            padding:10px 0;border-bottom:1px solid #F0F0F5;align-items:center;'>
                    <div style='font-family:Space Mono,monospace;font-size:11px;color:#4A4E6A;'>{ts}</div>
                    <div style='font-size:13px;font-weight:600;color:#0D0F1A;'>{entry["action"]}</div>
                    <div style='font-size:12px;color:#4A4E6A;'>{entry["actor"]}</div>
                    <div><span style='font-size:11px;font-weight:600;color:{status_color};'>{status}</span></div>
                    <div style='font-family:Space Mono,monospace;font-size:10px;color:#9CA3AF;'>{entry["payload_hash"]}</div>
                </div>""", unsafe_allow_html=True)
        else:
            st.info("No transactions recorded yet in this session.")

        if st.button("📥 Export Audit Log as CSV"):
            if st.session_state.audit_trail:
                df = pd.DataFrame(st.session_state.audit_trail)
                st.download_button("Download CSV", df.to_csv(index=False), "audit_log.csv", "text/csv")

    with tab2:
        if st.session_state.governance_notes:
            for note in st.session_state.governance_notes:
                # FIX-04: use st.code to avoid any HTML injection risk with AI content
                st.markdown(f"""
                <div class='gov-note' style='margin-bottom:16px;'>
                    <h4>Governance Decision — {note.get('project_id','N/A')}</h4>
                    <div style='font-size:11px;color:#9CA3AF;margin-bottom:8px;'>
                        Issued: {note.get('timestamp','')} · Model: {note.get('generated_by','')}
                    </div>
                </div>""", unsafe_allow_html=True)
                st.code(note.get("content", ""), language=None)
        else:
            st.info("No governance notes generated yet. Run the Delivery Lead inference workflow to generate one.")

    with tab3:
        st.markdown("""
        <div class='gov-note'>
            <h4>PII Anonymization Architecture — Proof of Compliance</h4>
            <p style='font-size:13px;color:#0D0F1A;'>
                This platform applies a two-stage anonymization pipeline
                <strong>before</strong> any data reaches the Claude API:
            </p>
            <ol style='font-size:13px;color:#4A4E6A;line-height:2;'>
                <li><strong>Employee ID &amp; Name</strong> → SHA-256 + enterprise salt → 12-char hex token (irreversible)</li>
                <li><strong>Salary</strong> → Bucketed into $20k statistical bands (exact value never transmitted)</li>
                <li><strong>Performance scores</strong> → Converted to numeric weights only (labels stripped)</li>
                <li><strong>Original IDs</strong> → Held exclusively in server-side session state, never passed to AI</li>
            </ol>
            <p style='font-size:12px;color:#6B7280;margin-top:8px;'>
                Regulatory alignment: GDPR Article 25 (Privacy by Design), PDPA, IT Act 2000 (India).
            </p>
        </div>
        """, unsafe_allow_html=True)

        sample_emp = st.session_state.raw_employees[0]
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("**Raw record (never sent to AI)**")
            st.json({
                "employee_id":       sample_emp["employee_id"],
                "full_name":         sample_emp["full_name"],
                "current_salary":    sample_emp["current_salary"],
                "performance_score": sample_emp["performance_score"],
            })
        with col_b:
            st.markdown("**Anonymized payload (what Claude sees)**")
            st.json({
                "masked_id":   hash_pii(sample_emp["employee_id"]),
                "salary_band": mask_salary(sample_emp["current_salary"]),
                "skills":      sample_emp["skills_tags"],
                "perf_weight": 1.0 if sample_emp["performance_score"] == "Exceeds" else 0.8,
            })


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 — ROLE: HR MANAGER
# ─────────────────────────────────────────────────────────────────────────────

elif user_role == "HR_Manager":
    write_audit_log("HR_Manager", "READ_RAW_HR_DIRECTORY", "SUCCESS",
                    {"records_accessed": len(st.session_state.raw_employees)},
                    "HR Manager accessed full PII directory")

    st.markdown('<div class="section-label">👤 HR Management Directory</div>', unsafe_allow_html=True)
    st.warning("⚠️ **Elevated Access:** You are viewing raw PII and compensation data. All access is audited.")

    tab_hr1, tab_hr2 = st.tabs(["👥 Employee Directory", "📊 Workforce Analytics"])

    with tab_hr1:
        for emp in st.session_state.raw_employees:
            perf       = emp["performance_score"]
            chip_class = "exceeds" if perf == "Exceeds" else ("under" if perf == "Underperforming" else "meets")
            initials   = "".join(w[0] for w in emp["full_name"].split()[:2])
            skills_html = "".join(f'<span class="skill-badge">{s}</span>' for s in emp["skills_tags"])
            st.markdown(f"""
            <div class='candidate-card'>
                <div style='display:flex;justify-content:space-between;align-items:flex-start;'>
                    <div>
                        <div style='display:flex;align-items:center;gap:10px;'>
                            <div style='width:38px;height:38px;border-radius:50%;background:#EFF4FF;
                                        display:flex;align-items:center;justify-content:center;
                                        font-weight:700;font-size:13px;color:#2563EB;'>
                                {initials}
                            </div>
                            <div>
                                <div style='font-weight:600;font-size:15px;color:#0D0F1A;'>{emp['full_name']}</div>
                                <div style='font-size:12px;color:#4A4E6A;'>
                                    {emp['employee_id']} · {emp['dept']} · {emp['yoe']}y exp
                                </div>
                            </div>
                        </div>
                        <div style='margin-top:10px;'>{skills_html}</div>
                    </div>
                    <div style='text-align:right;'>
                        <div class='chip {chip_class}'>{perf}</div>
                        <div style='font-family:Space Mono,monospace;font-size:16px;font-weight:700;
                                    color:#0D0F1A;margin-top:8px;'>${emp['current_salary']:,}</div>
                        <div style='font-size:11px;color:#4A4E6A;'>Utilization: {emp['utilization_pct']}%</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    with tab_hr2:
        hr_df = pd.DataFrame(st.session_state.raw_employees)
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Headcount",  len(hr_df))
        col2.metric("Avg Salary",       f"${hr_df['current_salary'].mean():,.0f}")
        col3.metric("Avg Utilization",  f"{hr_df['utilization_pct'].mean():.0f}%")
        exceeds_count = (hr_df["performance_score"] == "Exceeds").sum()
        col4.metric("High Performers",  f"{exceeds_count}/{len(hr_df)}")
        st.markdown("---")
        st.markdown("**Performance Distribution**")
        perf_counts = hr_df["performance_score"].value_counts().reset_index()
        perf_counts.columns = ["Performance", "Count"]
        st.bar_chart(perf_counts.set_index("Performance"))


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 — ROLE: EXECUTIVE SPONSOR
# ─────────────────────────────────────────────────────────────────────────────

elif user_role == "Executive_Sponsor":
    write_audit_log("Executive_Sponsor", "VIEW_KPI_DASHBOARD", "SUCCESS", {}, "Exec accessed KPI summary")
    st.markdown('<div class="section-label">📊 Executive Intelligence Dashboard</div>', unsafe_allow_html=True)

    total_pipeline_value = sum(
        p["max_hourly_rate"] * p["duration_weeks"] * 40 * p["headcount_needed"]
        for p in st.session_state.raw_projects
    )
    avg_margin     = sum(p["target_margin_pct"] for p in st.session_state.raw_projects) / len(st.session_state.raw_projects)
    active_projects = sum(1 for p in st.session_state.raw_projects if p["status"] == "Active")

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='metric-label'>Pipeline Value</div>
            <div class='metric-value'>${total_pipeline_value/1_000_000:.1f}M</div>
            <div class='metric-sub'>Across {len(st.session_state.raw_projects)} projects</div>
        </div>""", unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
        <div class='metric-card success'>
            <div class='metric-label'>Avg Target Margin</div>
            <div class='metric-value'>{avg_margin:.1f}%</div>
            <div class='metric-sub'>Across active projects</div>
        </div>""", unsafe_allow_html=True)
    with c3:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='metric-label'>Approved Staffings</div>
            <div class='metric-value'>{len(st.session_state.approved_history)}</div>
            <div class='metric-sub'>This session</div>
        </div>""", unsafe_allow_html=True)
    with c4:
        st.markdown(f"""
        <div class='metric-card warn'>
            <div class='metric-label'>Pending HITL</div>
            <div class='metric-value'>{len(st.session_state.pending_approvals)}</div>
            <div class='metric-sub'>Awaiting human approval</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**Active Project Pipeline**")
    for proj in st.session_state.raw_projects:
        status_color = "#059669" if proj["status"] == "Active" else "#D97706"
        proj_value   = proj["max_hourly_rate"] * proj["duration_weeks"] * 40 * proj["headcount_needed"]
        skills_html  = "".join(f'<span class="skill-badge">{s}</span>' for s in proj["required_skills"])
        st.markdown(f"""
        <div class='candidate-card'>
            <div style='display:flex;justify-content:space-between;align-items:center;'>
                <div>
                    <div style='display:flex;align-items:center;gap:8px;'>
                        <span style='font-family:Space Mono,monospace;font-size:12px;
                                     color:#2563EB;font-weight:700;'>{proj['project_id']}</span>
                        <span style='font-size:12px;font-weight:600;color:{status_color};'>
                            ● {proj['status']}
                        </span>
                    </div>
                    <div style='font-size:15px;font-weight:600;color:#0D0F1A;margin-top:4px;'>
                        {proj['client_id']}
                        <span style='color:#9CA3AF;font-weight:400;font-size:13px;'>
                            ({proj['industry']})
                        </span>
                    </div>
                    <div style='margin-top:8px;'>{skills_html}</div>
                </div>
                <div style='text-align:right;'>
                    <div style='font-family:Space Mono,monospace;font-size:18px;
                                font-weight:700;color:#0D0F1A;'>${proj_value/1000:.0f}K</div>
                    <div style='font-size:11px;color:#4A4E6A;'>
                        {proj['target_margin_pct']}% margin · {proj['duration_weeks']}w · {proj['headcount_needed']} staff
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 9 — ROLE: DELIVERY LEAD (Main AI Inference Workflow)
# ─────────────────────────────────────────────────────────────────────────────

elif user_role == "Delivery_Lead":
    st.markdown('<div class="section-label">🚀 AI Staffing Allocation Engine</div>', unsafe_allow_html=True)

    with st.expander("📐 View Governance Data Flow Model", expanded=False):
        st.markdown("""
        <div style='display:flex;flex-direction:column;gap:4px;max-width:600px;'>
            <div class='flow-step active'>① Raw Employee Data (PII + Salary) — Server Session Only</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>② Anonymization Middleware — SHA-256 Hash + Salary Banding</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>③ Guardrail Engine — Policy checks before AI call</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>④ Sanitized Payload → Claude API (zero PII)</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>⑤ AI Recommendation + Guardrail Re-validation</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>⑥ Human-in-the-Loop Approval Queue</div>
            <div class='flow-arrow'>↓</div>
            <div class='flow-step active'>⑦ Production Release + Audit Log Entry</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    left_col, right_col = st.columns([1, 2], gap="large")

    # ── LEFT: Configuration ─────────────────────────────────────────────────
    with left_col:
        st.markdown("#### ⚙️ Configuration")
        selected_proj_id = st.selectbox(
            "Target Project",
            [p["project_id"] for p in st.session_state.raw_projects],
            format_func=lambda x: f"{x} — {next(p['client_id'] for p in st.session_state.raw_projects if p['project_id'] == x)}",
        )
        target_project = next(p for p in st.session_state.raw_projects if p["project_id"] == selected_proj_id)

        req_skills_html = "".join(f'<span class="skill-badge match">{s}</span>' for s in target_project["required_skills"])
        st.markdown(f"""
        <div class='metric-card' style='margin-top:12px;'>
            <div class='metric-label'>Project Brief</div>
            <div style='font-size:16px;font-weight:700;color:#0D0F1A;margin:4px 0;'>
                {target_project['client_id']}
            </div>
            <div style='font-size:12px;color:#4A4E6A;'>
                {target_project['industry']} · {target_project['duration_weeks']}w · {target_project['headcount_needed']} headcount
            </div>
            <div style='margin-top:10px;border-top:1px solid #E1E2EA;padding-top:10px;'>
                <div style='font-size:12px;font-weight:600;color:#4A4E6A;margin-bottom:6px;'>Required Skills</div>
                {req_skills_html}
            </div>
            <div style='margin-top:10px;display:flex;gap:16px;'>
                <div>
                    <div style='font-size:11px;color:#4A4E6A;'>Max Rate</div>
                    <div style='font-family:Space Mono,monospace;font-weight:700;'>
                        ${target_project['max_hourly_rate']:.0f}/hr
                    </div>
                </div>
                <div>
                    <div style='font-size:11px;color:#4A4E6A;'>Target Margin</div>
                    <div style='font-family:Space Mono,monospace;font-weight:700;'>
                        {target_project['target_margin_pct']}%
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### 🛡️ Policy Guardrails")
        allow_underperforming = st.checkbox(
            "Allow underperforming profiles", value=False,
            help="When OFF: system blocks candidates flagged as 'Underperforming' regardless of skill match",
        )
        margin_floor = st.slider("Minimum margin threshold (%)", 15, 50, 25,
            help="AI recommendation is rejected if projected margin falls below this")
        require_exceeds = st.checkbox("Require at least one 'Exceeds' performer per project", value=True)
        max_utilization = st.slider("Max candidate utilization (%)", 50, 100, 85,
            help="Prevents over-allocation — candidates above this are excluded")

        st.markdown("#### 🤖 AI Settings")
        ai_focus = st.selectbox("AI Analysis Focus", [
            "Balanced (margin + skills + performance)",
            "Margin-first (prioritize profitability)",
            "Skills-first (best technical fit)",
            "Risk-aware (flag all compliance concerns)",
        ])

        trigger_btn = st.button("▶ Run Governance-Compliant Inference", type="primary", use_container_width=True)

    # ── RIGHT: Inference Workspace ──────────────────────────────────────────
    with right_col:
        st.markdown("#### 🔒 Anonymization & Inference Workspace")

        if trigger_btn:
            # ── PHASE 1: ANONYMIZE ─────────────────────────────────────────
            with st.spinner("Phase 1/4: Applying PII anonymization middleware..."):
                time.sleep(0.5)
                anonymized_pool = []
                for emp in st.session_state.raw_employees:
                    if emp["utilization_pct"] > max_utilization:
                        continue
                    anonymized_pool.append({
                        "masked_id":    hash_pii(emp["employee_id"]),
                        "salary_band":  mask_salary(emp["current_salary"]),
                        "skills":       emp["skills_tags"],
                        "perf_weight":  1.0 if emp["performance_score"] == "Exceeds"
                                        else (0.8 if emp["performance_score"] == "Meets" else 0.4),
                        "yoe_band":     f"{(emp['yoe'] // 3)*3}–{(emp['yoe'] // 3)*3+3} years",
                        # Server-side only — NEVER sent to AI
                        "_original_id":  emp["employee_id"],
                        "_raw_perf":     emp["performance_score"],
                        "_raw_salary":   emp["current_salary"],
                    })
                write_audit_log("ANONYMIZATION_ENGINE", "DATA_MASK", "SUCCESS",
                                {"pool_size": len(anonymized_pool), "project": selected_proj_id})

            col_a, col_b = st.columns(2)
            col_a.metric("Candidates in Pool",  len(anonymized_pool))
            col_b.metric("PII Fields Stripped", "5 per record")

            st.markdown("**Sanitized payload sample (first 2 records) — sent to Claude:**")
            safe_display = [{k: v for k, v in r.items() if not k.startswith("_")} for r in anonymized_pool[:2]]
            st.json(safe_display)

            # ── PHASE 2: PRE-INFERENCE GUARDRAIL CHECK ─────────────────────
            with st.spinner("Phase 2/4: Running pre-inference policy guardrails..."):
                time.sleep(0.4)

            st.markdown("---")
            st.markdown("**Pre-Inference Guardrail Results**")
            pre_violations = []
            if len(anonymized_pool) == 0:
                pre_violations.append("No candidates available after utilization filter — expand utilization threshold.")

            for v in pre_violations:
                st.markdown(
                    f'<div class="guardrail-item fail">'
                    f'<div class="guardrail-icon">🛑</div>'
                    f'<div><div class="guardrail-title">Pre-check Violation</div>'
                    f'<div class="guardrail-desc">{v}</div></div></div>',
                    unsafe_allow_html=True,
                )

            if not pre_violations:
                st.markdown(
                    '<div class="guardrail-item pass">'
                    '<div class="guardrail-icon">✅</div>'
                    '<div><div class="guardrail-title">Pool integrity check</div>'
                    '<div class="guardrail-desc">Anonymized candidate pool is non-empty and compliant.</div>'
                    '</div></div>',
                    unsafe_allow_html=True,
                )

            # ── PHASE 3: AI INFERENCE ──────────────────────────────────────
            with st.spinner("Phase 3/4: Routing sanitized payload to Claude inference engine..."):
                time.sleep(0.3)

                clean_pool = [{k: v for k, v in r.items() if not k.startswith("_")} for r in anonymized_pool]

                system_prompt = f"""You are an enterprise staffing optimization AI embedded in a governance-compliant platform.
You receive ONLY anonymized candidate data — no real names, no exact salaries, no employee IDs.
Your role: analyze skill fit, estimate margin contribution, and produce a ranked recommendation.

Focus mode: {ai_focus}
Project target margin floor: {margin_floor}%
Max hourly rate: ${target_project['max_hourly_rate']}/hr
Required skills: {', '.join(target_project['required_skills'])}
Duration: {target_project['duration_weeks']} weeks
Headcount needed: {target_project['headcount_needed']}

Output a structured analysis in this EXACT format:
---GOVERNANCE DECISION NOTE---
Project: {selected_proj_id}
Client: {target_project['client_id']}
Data sensitivity: HIGH — PII anonymized via SHA-256 + salary banding
AI inference boundary: No PII fields present in this context
Regulatory alignment: GDPR Art.25, PDPA, IT Act 2000

RANKED RECOMMENDATIONS:
[List top candidates by masked_id with: skill match %, estimated margin %, suitability score, risk flags]

GOVERNANCE RISK FLAGS:
[List any concerns: margin breach risk, skill gap, performance weight concerns]

COMPLIANCE ATTESTATION:
[Confirm data handling compliance and recommend human review points]
---END NOTE---"""

                user_message = (
                    f"Project: {selected_proj_id}\n"
                    f"Required skills: {target_project['required_skills']}\n"
                    f"Anonymized candidate pool:\n{json.dumps(clean_pool, indent=2)}\n\n"
                    "Provide ranked staffing recommendations and governance decision note."
                )

                is_error = False
                if api_key_input:
                    ai_response, is_error = call_claude_api(system_prompt, user_message, api_key_input)
                    log_status = "API_ERROR" if is_error else "SUCCESS"
                    write_audit_log(
                        "CLAUDE_ENGINE", "AI_INFERENCE", log_status,
                        {"project": selected_proj_id, "model": ANTHROPIC_MODEL, "candidates": len(clean_pool)},
                        "Claude inference completed on anonymized payload" if not is_error else ai_response[:120],
                    )
                else:
                    # Demo mode — simulated response
                    ai_response = (
                        f"---GOVERNANCE DECISION NOTE---\n"
                        f"Project: {selected_proj_id}\n"
                        f"Client: {target_project['client_id']}\n"
                        f"Data sensitivity: HIGH — PII anonymized via SHA-256 + salary banding\n"
                        f"AI inference boundary: No PII fields present in this context\n"
                        f"Regulatory alignment: GDPR Art.25, PDPA, IT Act 2000\n\n"
                        f"RANKED RECOMMENDATIONS:\n"
                        f"1. Candidate {hash_pii('EMP-00103')} — Skills: 100% match | Est. margin: 42.3% | Score: 9.2/10 | Risk: None\n"
                        f"2. Candidate {hash_pii('EMP-00101')} — Skills: 75% match  | Est. margin: 38.1% | Score: 7.8/10 | Risk: Minor skill gap\n"
                        f"3. Candidate {hash_pii('EMP-00107')} — Skills: 50% match  | Est. margin: 35.6% | Score: 6.1/10 | Risk: Upskilling needed\n\n"
                        f"GOVERNANCE RISK FLAGS:\n"
                        f"• Candidate 3 has partial skill overlap — recommend pre-project training\n"
                        f"• All recommendations exceed the {margin_floor}% margin floor — compliant\n"
                        f"• Performance weights applied: high performers prioritized per policy\n\n"
                        f"COMPLIANCE ATTESTATION:\n"
                        f"All data processed in this inference context is anonymized. No names, exact salaries,\n"
                        f"or identifiable information was present in the payload.\n"
                        f"Human sign-off required per HITL policy before any allocation.\n"
                        f"---END NOTE---\n\n"
                        f"[DEMO MODE — Add Anthropic API key in sidebar for live Claude inference]"
                    )
                    write_audit_log(
                        "CLAUDE_ENGINE", "AI_INFERENCE", "DEMO_MODE",
                        {"project": selected_proj_id, "note": "No API key provided"},
                        "Demo response generated — no real inference",
                    )

            # ── FIX-02: single clean render — no double pre+div ─────────────
            st.markdown("---")
            st.markdown("#### 🤖 Claude Governance Decision Note")

            if is_error:
                # FIX-03: Friendly error panel instead of raw JSON dump
                st.markdown(f"""
                <div class='error-banner'>
                    <div class='err-title'>⚠️ AI Inference Unavailable</div>
                    <div class='err-body'><pre style='margin:0;font-family:inherit;white-space:pre-wrap;'>{ai_response}</pre></div>
                </div>
                """, unsafe_allow_html=True)
                st.info("💡 The match ranking below uses rule-based scoring and does not require the API.")
            else:
                st.markdown('<div class="ai-panel">', unsafe_allow_html=True)
                # st.code renders monospace, scrollable, copy-button — safe from HTML injection
                st.code(ai_response, language=None)
                st.markdown("</div>", unsafe_allow_html=True)

            # Save governance note regardless of error state
            st.session_state.governance_notes.insert(0, {
                "project_id":    selected_proj_id,
                "content":       ai_response,
                "timestamp":     datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
                "generated_by":  ANTHROPIC_MODEL if (api_key_input and not is_error) else ("API_ERROR" if is_error else "DEMO_MODE"),
            })

            # ── PHASE 4: POST-INFERENCE GUARDRAILS + CANDIDATE MATCHING ────
            with st.spinner("Phase 4/4: Post-inference guardrail validation + match scoring..."):
                time.sleep(0.4)

                matches = []
                for candidate in anonymized_pool:
                    matching = set(candidate["skills"]).intersection(set(target_project["required_skills"]))
                    if not matching:
                        continue
                    raw_salary  = candidate["_raw_salary"]
                    hourly_cost = (raw_salary / 2080) * 1.35          # loaded cost factor
                    margin      = ((target_project["max_hourly_rate"] - hourly_cost) / target_project["max_hourly_rate"]) * 100
                    skill_score = len(matching) / len(target_project["required_skills"])
                    suitability = round(
                        (skill_score * 0.5) + (min(margin, 50) / 50 * 0.3) + (candidate["perf_weight"] * 0.2),
                        3,
                    )
                    matches.append({
                        "masked_id":      candidate["masked_id"],
                        "matched_skills": list(matching),
                        "all_skills":     candidate["skills"],        # FIX-01: full skill list for display
                        "skill_pct":      round(skill_score * 100),
                        "proj_margin":    round(margin, 1),
                        "perf_weight":    candidate["perf_weight"],
                        "suitability":    suitability,
                        "_original_id":   candidate["_original_id"],
                        "_raw_perf":      candidate["_raw_perf"],
                        "_salary":        raw_salary,
                    })

                matches.sort(key=lambda x: x["suitability"], reverse=True)

            st.markdown("---")
            st.markdown("#### 🎯 Post-Inference Match Ranking")

            if not matches:
                st.warning("No candidates matched required skills for this project.")
            else:
                for i, m in enumerate(matches[:5]):
                    is_top = i == 0

                    # Guardrail evaluation
                    grs      = []
                    all_pass = True

                    if m["proj_margin"] < margin_floor:
                        grs.append(("fail", f"Margin {m['proj_margin']}% < floor {margin_floor}%"))
                        all_pass = False
                    else:
                        grs.append(("pass", f"Margin {m['proj_margin']}% ≥ floor {margin_floor}%"))

                    if not allow_underperforming and m["_raw_perf"] == "Underperforming":
                        grs.append(("fail", "Performance policy: Underperforming candidates blocked"))
                        all_pass = False
                    else:
                        grs.append(("pass", f"Performance weight: {m['perf_weight']} — policy compliant"))

                    gr_html = "".join(
                        f'<span style="font-size:11px;font-weight:600;'
                        f'color:{"#059669" if g == "pass" else "#DC2626"};">'
                        f'{"✓" if g == "pass" else "✗"} {txt}</span><br>'
                        for g, txt in grs
                    )

                    # ── FIX-01: build skills_html from THIS candidate's own skill list ──
                    # Show matched skills first (highlighted), then remaining skills (muted)
                    req_set      = set(target_project["required_skills"])
                    matched_set  = set(m["matched_skills"])
                    other_skills = [s for s in m["all_skills"] if s not in matched_set]
                    display_skills = (
                        [s for s in m["matched_skills"]]   # matched first
                        + other_skills                      # then the rest
                    )[:6]

                    skills_html = "".join(
                        f'<span class="skill-badge {"match" if s in req_set else ""}">'
                        f'{"✓ " if s in req_set else ""}{s}</span>'
                        for s in display_skills
                    )
                    # ── end FIX-01 ──────────────────────────────────────────

                    rank_label = ["🥇 Top Pick", "🥈 2nd", "🥉 3rd", "4th", "5th"][i]
                    card_class = "candidate-card top-pick" if is_top else "candidate-card"
                    rec_badge  = (
                        '<span style="font-size:11px;color:#059669;font-weight:600;'
                        'background:#ECFDF5;padding:2px 8px;border-radius:6px;">RECOMMENDED</span>'
                        if is_top and all_pass else ""
                    )
                    block_badge = (
                        '<span style="font-size:11px;color:#DC2626;font-weight:600;'
                        'background:#FEF2F2;padding:2px 8px;border-radius:6px;">BLOCKED</span>'
                        if not all_pass else ""
                    )
                    score_color = "#2563EB" if is_top else "#0D0F1A"

                    st.markdown(f"""
                    <div class='{card_class}'>
                        <div style='display:flex;justify-content:space-between;align-items:flex-start;'>
                            <div style='flex:1;'>
                                <div style='display:flex;align-items:center;gap:8px;margin-bottom:8px;'>
                                    <span style='font-size:16px;'>{rank_label}</span>
                                    <span style='font-family:Space Mono,monospace;font-size:12px;color:#2563EB;
                                                 background:#EFF4FF;padding:2px 8px;border-radius:6px;'>
                                        {m['masked_id']}
                                    </span>
                                    {rec_badge}{block_badge}
                                </div>
                                <div style='margin-bottom:8px;'>{skills_html}</div>
                                <div>{gr_html}</div>
                            </div>
                            <div style='text-align:right;min-width:120px;margin-left:20px;'>
                                <div style='font-size:11px;color:#4A4E6A;'>Suitability Score</div>
                                <div style='font-family:Space Mono,monospace;font-size:22px;
                                            font-weight:700;color:{score_color};'>
                                    {m["suitability"]:.2f}
                                </div>
                                <div style='font-size:12px;color:#4A4E6A;margin-top:4px;'>
                                    Margin: {m["proj_margin"]}%
                                </div>
                                <div style='font-size:12px;color:#4A4E6A;'>
                                    Skill fit: {m["skill_pct"]}%
                                </div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    # Add to HITL queue if top pick & passes guardrails
                    if is_top and all_pass:
                        prop_id  = f"PROP-{str(uuid.uuid4())[:6].upper()}"
                        proposal = {
                            "proposal_id":        prop_id,
                            "project_id":         target_project["project_id"],
                            "client":             target_project["client_id"],
                            "masked_employee_id": m["masked_id"],
                            "_real_employee_id":  m["_original_id"],
                            "projected_margin":   m["proj_margin"],
                            "suitability_score":  m["suitability"],
                            "skill_pct":          m["skill_pct"],
                            "ai_focus":           ai_focus,
                            "submitted_at":       datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                            "submitted_by":       "Delivery_Lead",
                        }
                        existing_keys = [p["masked_employee_id"] + p["project_id"] for p in st.session_state.pending_approvals]
                        if (m["masked_id"] + target_project["project_id"]) not in existing_keys:
                            st.session_state.pending_approvals.append(proposal)
                            write_audit_log("AI_ENGINE", "HITL_QUEUE_PUSH", "SUCCESS",
                                            {"proposal": prop_id, "project": selected_proj_id})
                            st.success(f"✅ Proposal **{prop_id}** dispatched to HITL approval queue.")
                        else:
                            st.info("Proposal for this candidate + project already in queue.")

                    elif is_top and not all_pass:
                        write_audit_log(
                            "SYSTEM_GUARDRAIL", "GUARDRAIL_BLOCK", "POLICY_VIOLATION",
                            {"candidate": m["masked_id"], "project": selected_proj_id},
                            f"Top pick blocked: {[txt for g, txt in grs if g == 'fail']}",
                        )
                        st.error("🛑 Top recommendation blocked by guardrail policy. Proposal not queued.")

    # ── HITL APPROVAL QUEUE ────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("#### 🤝 Human-in-the-Loop Routing Queue")
    st.caption("All AI-generated proposals require explicit human authorization before any production staffing action.")

    if not st.session_state.pending_approvals:
        st.markdown("""
        <div style='text-align:center;padding:32px;background:#F5F5F8;
                    border-radius:12px;border:1px dashed #E1E2EA;'>
            <div style='font-size:24px;margin-bottom:8px;'>✨</div>
            <div style='font-size:14px;color:#4A4E6A;'>Queue is clear — no pending approvals</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        for prop in st.session_state.pending_approvals:
            st.markdown(f"""
            <div class='proposal-card'>
                <div>
                    <div class='proposal-id'>{prop['proposal_id']}</div>
                    <div class='proposal-meta'>
                        {prop['project_id']} · {prop['client']} · Candidate: {prop['masked_employee_id']}
                    </div>
                    <div class='proposal-meta' style='margin-top:3px;'>
                        Margin: {prop['projected_margin']}% · Score: {prop['suitability_score']:.2f}
                        · Skill: {prop['skill_pct']}% · Submitted: {prop['submitted_at']}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        selected_prop_id = st.selectbox(
            "Select proposal to action:",
            [p["proposal_id"] for p in st.session_state.pending_approvals],
        )
        matched_prop = next(p for p in st.session_state.pending_approvals if p["proposal_id"] == selected_prop_id)

        col_approve, col_reject = st.columns(2)
        with col_approve:
            if st.button("✅ Authorize Production Release", type="primary", use_container_width=True):
                write_audit_log(
                    "Delivery_Lead", "HUMAN_APPROVE", "SUCCESS",
                    {"proposal": selected_prop_id, "real_emp": matched_prop["_real_employee_id"]},
                    "Human authorized staffing assignment for production",
                )
                st.session_state.approved_history.append({
                    **matched_prop,
                    "decision":   "APPROVED",
                    "decided_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                })
                st.session_state.pending_approvals.remove(matched_prop)
                st.toast(f"✅ {selected_prop_id} authorized — assignment released to production!", icon="🚀")
                time.sleep(0.5)
                st.rerun()

        with col_reject:
            if st.button("🚫 Reject & Return to Pool", use_container_width=True):
                write_audit_log(
                    "Delivery_Lead", "HUMAN_REJECT", "REJECTED",
                    {"proposal": selected_prop_id},
                    "Human rejected AI recommendation — candidate returned to pool",
                )
                st.session_state.rejected_history.append({
                    **matched_prop,
                    "decision":   "REJECTED",
                    "decided_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                })
                st.session_state.pending_approvals.remove(matched_prop)
                st.toast(f"🚫 {selected_prop_id} rejected.", icon="❌")
                time.sleep(0.5)
                st.rerun()

    # ── APPROVED HISTORY ───────────────────────────────────────────────────
    if st.session_state.approved_history:
        st.markdown("---")
        st.markdown("#### ✅ Approved Staffing History (This Session)")
        approved_df = pd.DataFrame([{
            "Proposal":         a["proposal_id"],
            "Project":          a["project_id"],
            "Client":           a["client"],
            "Candidate (Masked)": a["masked_employee_id"],
            "Margin %":         a["projected_margin"],
            "Score":            a["suitability_score"],
            "Decided":          a["decided_at"],
        } for a in st.session_state.approved_history])
        st.dataframe(approved_df, use_container_width=True, hide_index=True)
